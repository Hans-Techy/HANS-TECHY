# Roadmap
- [x] Admin can delete wrong expenses and purchases (stock reversed)
- [x] Admin can edit users (name, phone, role, deactivate)
- [x] Multi-business: each signup gets its own isolated business
- [x] Owner adds staff (name, email, password, role) and deletes staff accounts
- [x] Delete customers
- [x] Forgot password + reset page
- [x] Audit log removed

- [x] Install App (PWA manifest + menu button)
- [x] Edit sale (admin)
- [x] Manage categories
