CREATE OR REPLACE FUNCTION public.sync_staff_business(p_user_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE
  v_meta jsonb; v_biz uuid; v_role public.app_role; v_old uuid;
BEGIN
  SELECT raw_app_meta_data INTO v_meta FROM auth.users WHERE id = p_user_id;
  v_biz := NULLIF(v_meta->>'business_id','')::uuid;
  IF v_biz IS NULL OR NOT EXISTS (SELECT 1 FROM public.businesses WHERE id = v_biz) THEN RETURN; END IF;
  v_role := COALESCE(NULLIF(v_meta->>'role',''),'salesperson')::public.app_role;
  SELECT business_id INTO v_old FROM public.profiles WHERE id = p_user_id;
  UPDATE public.profiles SET business_id = v_biz WHERE id = p_user_id;
  DELETE FROM public.user_roles WHERE user_id = p_user_id;
  INSERT INTO public.user_roles (user_id, role) VALUES (p_user_id, v_role);
  IF v_old IS NOT NULL AND v_old <> v_biz THEN
    DELETE FROM public.businesses b WHERE b.id = v_old AND b.owner_id = p_user_id
      AND NOT EXISTS (SELECT 1 FROM public.profiles WHERE business_id = b.id)
      AND NOT EXISTS (SELECT 1 FROM public.products WHERE business_id = b.id)
      AND NOT EXISTS (SELECT 1 FROM public.sales WHERE business_id = b.id);
  END IF;
END; $$;
REVOKE ALL ON FUNCTION public.sync_staff_business(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.sync_staff_business(uuid) TO service_role;

SELECT public.sync_staff_business(u.id) FROM auth.users u
JOIN public.profiles p ON p.id = u.id
WHERE NULLIF(u.raw_app_meta_data->>'business_id','') IS NOT NULL
  AND p.business_id::text IS DISTINCT FROM u.raw_app_meta_data->>'business_id';