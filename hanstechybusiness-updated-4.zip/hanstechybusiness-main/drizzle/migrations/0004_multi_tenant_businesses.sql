
CREATE TABLE public.businesses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL DEFAULT 'My Business',
  phone TEXT,
  address TEXT,
  currency TEXT NOT NULL DEFAULT 'TZS',
  receipt_footer TEXT,
  owner_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, UPDATE ON public.businesses TO authenticated;
GRANT ALL ON public.businesses TO service_role;
ALTER TABLE public.businesses ENABLE ROW LEVEL SECURITY;

ALTER TABLE public.profiles ADD COLUMN business_id UUID REFERENCES public.businesses(id) ON DELETE CASCADE;

CREATE OR REPLACE FUNCTION public.my_business()
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT business_id FROM public.profiles WHERE id = auth.uid()
$$;
GRANT EXECUTE ON FUNCTION public.my_business() TO authenticated;

CREATE OR REPLACE FUNCTION public.same_business(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE id = _user_id AND business_id = public.my_business())
$$;

-- Legacy data: move into one business owned by the first admin
DO $$
DECLARE v_owner uuid; v_biz uuid;
BEGIN
  IF EXISTS (SELECT 1 FROM public.profiles) THEN
    SELECT user_id INTO v_owner FROM public.user_roles WHERE role = 'admin' LIMIT 1;
    INSERT INTO public.businesses (name, phone, address, currency, receipt_footer, owner_id)
    SELECT COALESCE((SELECT name FROM public.business_settings LIMIT 1), 'My Business'),
           (SELECT phone FROM public.business_settings LIMIT 1),
           (SELECT address FROM public.business_settings LIMIT 1),
           COALESCE((SELECT currency FROM public.business_settings LIMIT 1), 'TZS'),
           (SELECT receipt_footer FROM public.business_settings LIMIT 1),
           v_owner
    RETURNING id INTO v_biz;
    UPDATE public.profiles SET business_id = v_biz WHERE business_id IS NULL;
  END IF;
END $$;

DO $$
DECLARE t text; v_biz uuid;
BEGIN
  SELECT id INTO v_biz FROM public.businesses ORDER BY created_at LIMIT 1;
  FOREACH t IN ARRAY ARRAY['categories','suppliers','customers','products','sales','sale_items','purchases','purchase_items','payments','expenses'] LOOP
    EXECUTE format('ALTER TABLE public.%I ADD COLUMN business_id UUID REFERENCES public.businesses(id) ON DELETE CASCADE', t);
    IF v_biz IS NOT NULL THEN
      EXECUTE format('UPDATE public.%I SET business_id = %L WHERE business_id IS NULL', t, v_biz);
    END IF;
    EXECUTE format('ALTER TABLE public.%I ALTER COLUMN business_id SET DEFAULT public.my_business()', t);
    EXECUTE format('CREATE INDEX ON public.%I (business_id)', t);
  END LOOP;
END $$;

ALTER TABLE public.categories DROP CONSTRAINT IF EXISTS categories_name_key;
ALTER TABLE public.categories ADD CONSTRAINT categories_business_name_key UNIQUE (business_id, name);
ALTER TABLE public.products DROP CONSTRAINT IF EXISTS products_sku_key;
ALTER TABLE public.products ADD CONSTRAINT products_business_sku_key UNIQUE (business_id, sku);

-- New users: invited staff join the inviting business; self sign-ups create their own business
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_biz uuid := NULLIF(NEW.raw_app_meta_data->>'business_id','')::uuid;
  v_role public.app_role := COALESCE(NULLIF(NEW.raw_app_meta_data->>'role',''), 'salesperson')::public.app_role;
  v_name text := COALESCE(NULLIF(NEW.raw_user_meta_data->>'full_name',''), split_part(NEW.email,'@',1));
BEGIN
  IF v_biz IS NULL OR NOT EXISTS (SELECT 1 FROM public.businesses WHERE id = v_biz) THEN
    INSERT INTO public.businesses (name, owner_id)
    VALUES (COALESCE(NULLIF(NEW.raw_user_meta_data->>'business_name',''), v_name), NEW.id)
    RETURNING id INTO v_biz;
    v_role := 'admin';
  END IF;
  INSERT INTO public.profiles (id, full_name, phone, business_id)
  VALUES (NEW.id, v_name, NEW.raw_user_meta_data->>'phone', v_biz)
  ON CONFLICT (id) DO UPDATE SET business_id = EXCLUDED.business_id;
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, v_role) ON CONFLICT DO NOTHING;
  RETURN NEW;
END; $$;

-- Users cannot move themselves between businesses or reactivate themselves
CREATE OR REPLACE FUNCTION public.guard_profile_update()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF auth.uid() IS NOT NULL THEN
    NEW.business_id := OLD.business_id;
    IF NEW.active IS DISTINCT FROM OLD.active AND NOT public.has_role(auth.uid(), 'admin') THEN
      RAISE EXCEPTION 'Only admin can change user status';
    END IF;
  END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER trg_guard_profile_update BEFORE UPDATE ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.guard_profile_update();

-- Triggers stay inside one business
CREATE OR REPLACE FUNCTION public.apply_sale_item()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.product_id IS NOT NULL THEN
    UPDATE public.products SET quantity = quantity - NEW.quantity, updated_at = now()
    WHERE id = NEW.product_id AND business_id = NEW.business_id;
  END IF;
  RETURN NEW;
END; $$;

CREATE OR REPLACE FUNCTION public.apply_purchase_item()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.product_id IS NOT NULL THEN
    UPDATE public.products SET quantity = quantity + NEW.quantity, cost_price = NEW.unit_cost, updated_at = now()
    WHERE id = NEW.product_id AND business_id = NEW.business_id;
  END IF;
  RETURN NEW;
END; $$;

CREATE OR REPLACE FUNCTION public.apply_customer_payment()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE remaining NUMERIC := NEW.amount; s RECORD; applied NUMERIC;
BEGIN
  FOR s IN SELECT id, balance FROM public.sales
           WHERE customer_id = NEW.customer_id AND business_id = NEW.business_id AND balance > 0
           ORDER BY created_at ASC LOOP
    EXIT WHEN remaining <= 0;
    applied := LEAST(remaining, s.balance);
    UPDATE public.sales SET paid = paid + applied, balance = balance - applied WHERE id = s.id;
    remaining := remaining - applied;
  END LOOP;
  RETURN NEW;
END; $$;

CREATE OR REPLACE FUNCTION public.delete_sale(p_sale_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') OR NOT EXISTS (
    SELECT 1 FROM public.sales WHERE id = p_sale_id AND business_id = public.my_business()) THEN
    RAISE EXCEPTION 'Only admin can delete sales';
  END IF;
  UPDATE public.products p SET quantity = p.quantity + si.quantity, updated_at = now()
    FROM public.sale_items si WHERE si.sale_id = p_sale_id AND si.product_id = p.id;
  UPDATE public.payments SET sale_id = NULL WHERE sale_id = p_sale_id;
  DELETE FROM public.sale_items WHERE sale_id = p_sale_id;
  DELETE FROM public.sales WHERE id = p_sale_id;
END; $$;

CREATE OR REPLACE FUNCTION public.delete_purchase(p_purchase_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') OR NOT EXISTS (
    SELECT 1 FROM public.purchases WHERE id = p_purchase_id AND business_id = public.my_business()) THEN
    RAISE EXCEPTION 'Only admin can delete purchases';
  END IF;
  UPDATE public.products p SET quantity = p.quantity - pi.quantity, updated_at = now()
    FROM public.purchase_items pi WHERE pi.purchase_id = p_purchase_id AND pi.product_id = p.id;
  DELETE FROM public.purchase_items WHERE purchase_id = p_purchase_id;
  DELETE FROM public.purchases WHERE id = p_purchase_id;
END; $$;

CREATE OR REPLACE FUNCTION public.reset_transactions()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_biz uuid := public.my_business();
BEGIN
  IF v_biz IS NULL OR NOT public.is_manager(auth.uid()) THEN
    RAISE EXCEPTION 'Only admin or manager can reset transactions';
  END IF;
  DELETE FROM public.sale_items WHERE business_id = v_biz;
  DELETE FROM public.payments WHERE business_id = v_biz;
  DELETE FROM public.sales WHERE business_id = v_biz;
  DELETE FROM public.purchase_items WHERE business_id = v_biz;
  DELETE FROM public.purchases WHERE business_id = v_biz;
  DELETE FROM public.expenses WHERE business_id = v_biz;
END; $$;

CREATE OR REPLACE FUNCTION public.delete_customer(p_customer_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_manager(auth.uid()) OR NOT EXISTS (
    SELECT 1 FROM public.customers WHERE id = p_customer_id AND business_id = public.my_business()) THEN
    RAISE EXCEPTION 'Only admin or manager can delete customers';
  END IF;
  UPDATE public.sales SET customer_id = NULL WHERE customer_id = p_customer_id;
  DELETE FROM public.payments WHERE customer_id = p_customer_id;
  DELETE FROM public.customers WHERE id = p_customer_id;
END; $$;
GRANT EXECUTE ON FUNCTION public.delete_customer(uuid) TO authenticated;

-- Replace every policy with business-scoped ones
DO $$ DECLARE r record; BEGIN
  FOR r IN SELECT policyname, tablename FROM pg_policies WHERE schemaname = 'public'
    AND tablename IN ('categories','suppliers','customers','products','sales','sale_items','purchases','purchase_items','payments','expenses','profiles','user_roles') LOOP
    EXECUTE format('DROP POLICY %I ON public.%I', r.policyname, r.tablename);
  END LOOP;
END $$;

CREATE POLICY "biz read" ON public.businesses FOR SELECT TO authenticated USING (id = public.my_business());
CREATE POLICY "biz update" ON public.businesses FOR UPDATE TO authenticated
  USING (id = public.my_business() AND public.is_manager(auth.uid()));

CREATE POLICY "categories read" ON public.categories FOR SELECT TO authenticated USING (business_id = public.my_business());
CREATE POLICY "categories insert" ON public.categories FOR INSERT TO authenticated WITH CHECK (business_id = public.my_business());
CREATE POLICY "categories update" ON public.categories FOR UPDATE TO authenticated USING (business_id = public.my_business() AND (public.is_manager(auth.uid()) OR public.has_role(auth.uid(),'storekeeper')));
CREATE POLICY "categories delete" ON public.categories FOR DELETE TO authenticated USING (business_id = public.my_business() AND public.is_manager(auth.uid()));

CREATE POLICY "suppliers read" ON public.suppliers FOR SELECT TO authenticated USING (business_id = public.my_business());
CREATE POLICY "suppliers insert" ON public.suppliers FOR INSERT TO authenticated WITH CHECK (business_id = public.my_business() AND (public.is_manager(auth.uid()) OR public.has_role(auth.uid(),'storekeeper')));
CREATE POLICY "suppliers update" ON public.suppliers FOR UPDATE TO authenticated USING (business_id = public.my_business() AND (public.is_manager(auth.uid()) OR public.has_role(auth.uid(),'storekeeper')));
CREATE POLICY "suppliers delete" ON public.suppliers FOR DELETE TO authenticated USING (business_id = public.my_business() AND public.is_manager(auth.uid()));

CREATE POLICY "customers read" ON public.customers FOR SELECT TO authenticated USING (business_id = public.my_business() AND (public.is_manager(auth.uid()) OR public.has_role(auth.uid(),'salesperson')));
CREATE POLICY "customers insert" ON public.customers FOR INSERT TO authenticated WITH CHECK (business_id = public.my_business() AND (public.is_manager(auth.uid()) OR public.has_role(auth.uid(),'salesperson')));
CREATE POLICY "customers update" ON public.customers FOR UPDATE TO authenticated USING (business_id = public.my_business() AND (public.is_manager(auth.uid()) OR public.has_role(auth.uid(),'salesperson')));
CREATE POLICY "customers delete" ON public.customers FOR DELETE TO authenticated USING (business_id = public.my_business() AND public.is_manager(auth.uid()));

CREATE POLICY "products read" ON public.products FOR SELECT TO authenticated USING (business_id = public.my_business());
CREATE POLICY "products insert" ON public.products FOR INSERT TO authenticated WITH CHECK (business_id = public.my_business() AND (public.is_manager(auth.uid()) OR public.has_role(auth.uid(),'storekeeper')));
CREATE POLICY "products update" ON public.products FOR UPDATE TO authenticated USING (business_id = public.my_business() AND (public.is_manager(auth.uid()) OR public.has_role(auth.uid(),'storekeeper')));
CREATE POLICY "products delete" ON public.products FOR DELETE TO authenticated USING (business_id = public.my_business() AND public.has_role(auth.uid(),'admin'));

CREATE POLICY "sales read" ON public.sales FOR SELECT TO authenticated USING (business_id = public.my_business() AND (public.is_manager(auth.uid()) OR public.has_role(auth.uid(),'salesperson')));
CREATE POLICY "sales insert" ON public.sales FOR INSERT TO authenticated WITH CHECK (business_id = public.my_business() AND sold_by = auth.uid());
CREATE POLICY "sales update" ON public.sales FOR UPDATE TO authenticated USING (business_id = public.my_business() AND public.is_manager(auth.uid()));
CREATE POLICY "sales delete" ON public.sales FOR DELETE TO authenticated USING (business_id = public.my_business() AND public.has_role(auth.uid(),'admin'));

CREATE POLICY "sale_items read" ON public.sale_items FOR SELECT TO authenticated USING (business_id = public.my_business());
CREATE POLICY "sale_items insert" ON public.sale_items FOR INSERT TO authenticated WITH CHECK (business_id = public.my_business());
CREATE POLICY "sale_items delete" ON public.sale_items FOR DELETE TO authenticated USING (business_id = public.my_business() AND public.has_role(auth.uid(),'admin'));

CREATE POLICY "purchases read" ON public.purchases FOR SELECT TO authenticated USING (business_id = public.my_business() AND (public.is_manager(auth.uid()) OR public.has_role(auth.uid(),'storekeeper')));
CREATE POLICY "purchases insert" ON public.purchases FOR INSERT TO authenticated WITH CHECK (business_id = public.my_business() AND (public.is_manager(auth.uid()) OR public.has_role(auth.uid(),'storekeeper')));
CREATE POLICY "purchases update" ON public.purchases FOR UPDATE TO authenticated USING (business_id = public.my_business() AND public.is_manager(auth.uid()));
CREATE POLICY "purchases delete" ON public.purchases FOR DELETE TO authenticated USING (business_id = public.my_business() AND public.has_role(auth.uid(),'admin'));

CREATE POLICY "purchase_items read" ON public.purchase_items FOR SELECT TO authenticated USING (business_id = public.my_business());
CREATE POLICY "purchase_items insert" ON public.purchase_items FOR INSERT TO authenticated WITH CHECK (business_id = public.my_business() AND (public.is_manager(auth.uid()) OR public.has_role(auth.uid(),'storekeeper')));
CREATE POLICY "purchase_items delete" ON public.purchase_items FOR DELETE TO authenticated USING (business_id = public.my_business() AND public.has_role(auth.uid(),'admin'));

CREATE POLICY "payments read" ON public.payments FOR SELECT TO authenticated USING (business_id = public.my_business() AND (public.is_manager(auth.uid()) OR public.has_role(auth.uid(),'salesperson')));
CREATE POLICY "payments insert" ON public.payments FOR INSERT TO authenticated WITH CHECK (business_id = public.my_business() AND received_by = auth.uid());
CREATE POLICY "payments delete" ON public.payments FOR DELETE TO authenticated USING (business_id = public.my_business() AND public.has_role(auth.uid(),'admin'));

CREATE POLICY "expenses read" ON public.expenses FOR SELECT TO authenticated USING (business_id = public.my_business() AND public.is_manager(auth.uid()));
CREATE POLICY "expenses insert" ON public.expenses FOR INSERT TO authenticated WITH CHECK (business_id = public.my_business() AND public.is_manager(auth.uid()));
CREATE POLICY "expenses update" ON public.expenses FOR UPDATE TO authenticated USING (business_id = public.my_business() AND public.is_manager(auth.uid()));
CREATE POLICY "expenses delete" ON public.expenses FOR DELETE TO authenticated USING (business_id = public.my_business() AND public.has_role(auth.uid(),'admin'));

CREATE POLICY "profiles read" ON public.profiles FOR SELECT TO authenticated USING (id = auth.uid() OR business_id = public.my_business());
CREATE POLICY "profiles update" ON public.profiles FOR UPDATE TO authenticated
  USING (id = auth.uid() OR (business_id = public.my_business() AND public.has_role(auth.uid(),'admin')));

CREATE POLICY "roles read" ON public.user_roles FOR SELECT TO authenticated USING (user_id = auth.uid() OR public.same_business(user_id));
CREATE POLICY "roles admin manage" ON public.user_roles FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin') AND public.same_business(user_id) AND user_id <> auth.uid())
  WITH CHECK (public.has_role(auth.uid(),'admin') AND public.same_business(user_id) AND user_id <> auth.uid());

COMMENT ON TABLE public.business_settings IS 'DEPRECATED: replaced by public.businesses';
COMMENT ON TABLE public.audit_log IS 'DEPRECATED: audit log removed from the app';
