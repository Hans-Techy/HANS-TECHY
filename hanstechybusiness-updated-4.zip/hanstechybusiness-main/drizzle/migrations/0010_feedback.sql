CREATE TABLE public.feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL DEFAULT public.my_business(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  kind text NOT NULL DEFAULT 'general' CHECK (kind IN ('idea','bug','general')),
  message text NOT NULL CHECK (char_length(message) BETWEEN 1 AND 2000),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, DELETE ON public.feedback TO authenticated;
GRANT ALL ON public.feedback TO service_role;
ALTER TABLE public.feedback ENABLE ROW LEVEL SECURITY;
CREATE POLICY "members send feedback" ON public.feedback FOR INSERT TO authenticated
  WITH CHECK (business_id = public.my_business() AND user_id = auth.uid());
CREATE POLICY "managers read feedback" ON public.feedback FOR SELECT TO authenticated
  USING (business_id = public.my_business() AND (public.is_manager(auth.uid()) OR user_id = auth.uid()));
CREATE POLICY "managers delete feedback" ON public.feedback FOR DELETE TO authenticated
  USING (business_id = public.my_business() AND public.is_manager(auth.uid()));