
CREATE OR REPLACE FUNCTION public.my_business()
 RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$ SELECT business_id FROM public.profiles WHERE id = auth.uid() AND active $$;

CREATE OR REPLACE FUNCTION public.guard_sale_item()
 RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE pr RECORD;
BEGIN
  IF NEW.quantity IS NULL OR NEW.quantity <= 0 THEN RAISE EXCEPTION 'Invalid quantity'; END IF;
  IF NEW.product_id IS NOT NULL THEN
    SELECT * INTO pr FROM public.products WHERE id = NEW.product_id AND business_id = NEW.business_id;
    IF NOT FOUND THEN RAISE EXCEPTION 'Product not found'; END IF;
    NEW.product_name := pr.name;
    NEW.unit_cost := pr.cost_price;
    IF auth.uid() IS NOT NULL AND NOT public.is_manager(auth.uid()) THEN
      NEW.unit_price := pr.selling_price;
    END IF;
  ELSIF auth.uid() IS NOT NULL AND NOT public.is_manager(auth.uid()) THEN
    RAISE EXCEPTION 'Product required';
  END IF;
  IF NEW.unit_price < 0 THEN RAISE EXCEPTION 'Invalid price'; END IF;
  NEW.total := NEW.quantity * NEW.unit_price;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_guard_sale_item ON public.sale_items;
CREATE TRIGGER trg_guard_sale_item BEFORE INSERT ON public.sale_items
FOR EACH ROW EXECUTE FUNCTION public.guard_sale_item();

CREATE OR REPLACE FUNCTION public.recalc_sale_totals()
 RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_sub numeric; v_cost numeric; v_total numeric; s RECORD;
BEGIN
  SELECT COALESCE(SUM(total),0), COALESCE(SUM(quantity*unit_cost),0) INTO v_sub, v_cost
    FROM public.sale_items WHERE sale_id = NEW.sale_id;
  SELECT * INTO s FROM public.sales WHERE id = NEW.sale_id;
  v_total := GREATEST(0, v_sub - LEAST(GREATEST(COALESCE(s.discount,0),0), v_sub));
  UPDATE public.sales SET subtotal = v_sub, total = v_total, cost_total = v_cost,
    profit = v_total - v_cost, paid = LEAST(GREATEST(paid,0), v_total),
    balance = v_total - LEAST(GREATEST(paid,0), v_total)
  WHERE id = NEW.sale_id;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_recalc_sale_totals ON public.sale_items;
CREATE TRIGGER trg_recalc_sale_totals AFTER INSERT ON public.sale_items
FOR EACH ROW EXECUTE FUNCTION public.recalc_sale_totals();

CREATE OR REPLACE FUNCTION public.guard_payment()
 RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_owed numeric;
BEGIN
  IF NEW.amount IS NULL OR NEW.amount <= 0 THEN RAISE EXCEPTION 'Invalid amount'; END IF;
  SELECT COALESCE(SUM(balance),0) INTO v_owed FROM public.sales
    WHERE customer_id = NEW.customer_id AND business_id = NEW.business_id AND balance > 0;
  IF NEW.amount > v_owed THEN RAISE EXCEPTION 'Payment exceeds outstanding debt'; END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_guard_payment ON public.payments;
CREATE TRIGGER trg_guard_payment BEFORE INSERT ON public.payments
FOR EACH ROW EXECUTE FUNCTION public.guard_payment();

REVOKE EXECUTE ON FUNCTION public.guard_sale_item(), public.recalc_sale_totals(), public.guard_payment() FROM PUBLIC, anon, authenticated;
