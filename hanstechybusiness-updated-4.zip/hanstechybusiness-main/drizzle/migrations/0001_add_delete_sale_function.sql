CREATE OR REPLACE FUNCTION public.delete_sale(p_sale_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only admin can delete sales';
  END IF;

  -- Restore stock for every item on the sale
  UPDATE public.products p
     SET quantity = p.quantity + si.quantity,
         updated_at = now()
    FROM public.sale_items si
   WHERE si.sale_id = p_sale_id
     AND si.product_id = p.id;

  -- Keep payment records but unlink them from the deleted sale
  UPDATE public.payments SET sale_id = NULL WHERE sale_id = p_sale_id;

  DELETE FROM public.sale_items WHERE sale_id = p_sale_id;
  DELETE FROM public.sales WHERE id = p_sale_id;
END;
$function$;

GRANT EXECUTE ON FUNCTION public.delete_sale(uuid) TO authenticated;