CREATE OR REPLACE FUNCTION public.delete_purchase(p_purchase_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only admin can delete purchases';
  END IF;
  UPDATE public.products p SET quantity = p.quantity - pi.quantity, updated_at = now()
    FROM public.purchase_items pi WHERE pi.purchase_id = p_purchase_id AND pi.product_id = p.id;
  DELETE FROM public.purchase_items WHERE purchase_id = p_purchase_id;
  DELETE FROM public.purchases WHERE id = p_purchase_id;
END; $$;
REVOKE EXECUTE ON FUNCTION public.delete_purchase(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.delete_purchase(uuid) TO authenticated;

DROP POLICY IF EXISTS "sales read" ON public.sales;
CREATE POLICY "sales read" ON public.sales FOR SELECT TO authenticated
  USING (public.is_manager(auth.uid()) OR public.has_role(auth.uid(),'salesperson'));

DROP POLICY IF EXISTS "purchases read" ON public.purchases;
CREATE POLICY "purchases read" ON public.purchases FOR SELECT TO authenticated
  USING (public.is_manager(auth.uid()) OR public.has_role(auth.uid(),'storekeeper'));

DROP POLICY IF EXISTS "customers read" ON public.customers;
CREATE POLICY "customers read" ON public.customers FOR SELECT TO authenticated
  USING (public.is_manager(auth.uid()) OR public.has_role(auth.uid(),'salesperson'));
DROP POLICY IF EXISTS "customers insert" ON public.customers;
CREATE POLICY "customers insert" ON public.customers FOR INSERT TO authenticated
  WITH CHECK (public.is_manager(auth.uid()) OR public.has_role(auth.uid(),'salesperson'));
DROP POLICY IF EXISTS "customers update" ON public.customers;
CREATE POLICY "customers update" ON public.customers FOR UPDATE TO authenticated
  USING (public.is_manager(auth.uid()) OR public.has_role(auth.uid(),'salesperson'));