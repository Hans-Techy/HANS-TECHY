CREATE OR REPLACE FUNCTION public.reset_transactions()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  IF NOT public.is_manager(auth.uid()) THEN
    RAISE EXCEPTION 'Only admin or manager can reset transactions';
  END IF;

  -- Delete all transaction records; products, customers, suppliers and users stay intact
  DELETE FROM public.sale_items;
  DELETE FROM public.sales;
  DELETE FROM public.payments;
  DELETE FROM public.purchase_items;
  DELETE FROM public.purchases;
  DELETE FROM public.expenses;
  DELETE FROM public.audit_log;

  -- Record the reset itself in a fresh audit entry
  INSERT INTO public.audit_log (user_id, action, entity, details)
  VALUES (auth.uid(), 'system.reset', 'system', jsonb_build_object('note', 'All transactions cleared'));
END;
$function$;

GRANT EXECUTE ON FUNCTION public.reset_transactions() TO authenticated;