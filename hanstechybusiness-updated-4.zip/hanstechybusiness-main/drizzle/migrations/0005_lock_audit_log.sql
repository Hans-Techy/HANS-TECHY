DROP POLICY IF EXISTS "audit read" ON public.audit_log;
DROP POLICY IF EXISTS "audit insert" ON public.audit_log;
DROP POLICY IF EXISTS "settings read" ON public.business_settings;
DROP POLICY IF EXISTS "settings write" ON public.business_settings;