CREATE OR REPLACE FUNCTION public.update_sale(p_sale_id uuid, p_items jsonb, p_discount numeric, p_paid numeric, p_method public.payment_method)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_biz uuid := public.my_business(); it jsonb; pr RECORD; v_sub numeric := 0; v_cost numeric := 0; v_total numeric; v_paid numeric;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') OR NOT EXISTS (
    SELECT 1 FROM public.sales WHERE id = p_sale_id AND business_id = v_biz) THEN
    RAISE EXCEPTION 'Only admin can edit sales';
  END IF;
  IF jsonb_array_length(p_items) = 0 THEN RAISE EXCEPTION 'Sale needs at least one item'; END IF;
  -- restore old stock
  UPDATE public.products p SET quantity = p.quantity + si.quantity, updated_at = now()
    FROM public.sale_items si WHERE si.sale_id = p_sale_id AND si.product_id = p.id AND p.item_type <> 'service';
  DELETE FROM public.sale_items WHERE sale_id = p_sale_id;
  FOR it IN SELECT * FROM jsonb_array_elements(p_items) LOOP
    SELECT * INTO pr FROM public.products WHERE id = (it->>'product_id')::uuid AND business_id = v_biz;
    IF NOT FOUND THEN RAISE EXCEPTION 'Product not found'; END IF;
    IF (it->>'quantity')::numeric <= 0 THEN RAISE EXCEPTION 'Invalid quantity'; END IF;
    IF pr.item_type <> 'service' AND pr.quantity < (it->>'quantity')::numeric THEN
      RAISE EXCEPTION 'Insufficient stock: %', pr.name;
    END IF;
    INSERT INTO public.sale_items (sale_id, product_id, product_name, quantity, unit_price, unit_cost, total, business_id)
    VALUES (p_sale_id, pr.id, pr.name, (it->>'quantity')::numeric, (it->>'unit_price')::numeric, pr.cost_price,
            (it->>'quantity')::numeric * (it->>'unit_price')::numeric, v_biz);
    v_sub := v_sub + (it->>'quantity')::numeric * (it->>'unit_price')::numeric;
    v_cost := v_cost + (it->>'quantity')::numeric * pr.cost_price;
  END LOOP;
  v_total := GREATEST(0, v_sub - COALESCE(p_discount,0));
  v_paid := LEAST(GREATEST(COALESCE(p_paid,0),0), v_total);
  UPDATE public.sales SET subtotal = v_sub, discount = COALESCE(p_discount,0), total = v_total, paid = v_paid,
    balance = v_total - v_paid, cost_total = v_cost, profit = v_total - v_cost, payment_method = p_method
  WHERE id = p_sale_id;
  IF (v_total - v_paid) > 0 AND (SELECT customer_id FROM public.sales WHERE id = p_sale_id) IS NULL THEN
    RAISE EXCEPTION 'Select a customer to record the debt';
  END IF;
END; $$;
REVOKE ALL ON FUNCTION public.update_sale(uuid, jsonb, numeric, numeric, public.payment_method) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.update_sale(uuid, jsonb, numeric, numeric, public.payment_method) TO authenticated;

CREATE OR REPLACE FUNCTION public.delete_category(p_category_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_manager(auth.uid()) OR NOT EXISTS (
    SELECT 1 FROM public.categories WHERE id = p_category_id AND business_id = public.my_business()) THEN
    RAISE EXCEPTION 'Not allowed';
  END IF;
  UPDATE public.products SET category_id = NULL WHERE category_id = p_category_id;
  DELETE FROM public.categories WHERE id = p_category_id;
END; $$;
REVOKE ALL ON FUNCTION public.delete_category(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.delete_category(uuid) TO authenticated;