ALTER TABLE public.businesses ADD COLUMN IF NOT EXISTS tin text, ADD COLUMN IF NOT EXISTS email text, ADD COLUMN IF NOT EXISTS logo_url text;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS item_type text NOT NULL DEFAULT 'product';
ALTER TABLE public.expenses ADD COLUMN IF NOT EXISTS product_id uuid REFERENCES public.products(id) ON DELETE SET NULL, ADD COLUMN IF NOT EXISTS quantity numeric;

CREATE OR REPLACE FUNCTION public.apply_sale_item()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  IF NEW.product_id IS NOT NULL THEN
    UPDATE public.products SET quantity = quantity - NEW.quantity, updated_at = now()
    WHERE id = NEW.product_id AND business_id = NEW.business_id AND item_type <> 'service';
  END IF;
  RETURN NEW;
END; $$;

CREATE OR REPLACE FUNCTION public.apply_expense_stock()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  IF TG_OP = 'INSERT' AND NEW.product_id IS NOT NULL AND COALESCE(NEW.quantity,0) > 0 THEN
    UPDATE public.products SET quantity = quantity - NEW.quantity, updated_at = now()
    WHERE id = NEW.product_id AND business_id = NEW.business_id AND item_type <> 'service';
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' AND OLD.product_id IS NOT NULL AND COALESCE(OLD.quantity,0) > 0 THEN
    UPDATE public.products SET quantity = quantity + OLD.quantity, updated_at = now()
    WHERE id = OLD.product_id AND business_id = OLD.business_id AND item_type <> 'service';
    RETURN OLD;
  END IF;
  RETURN COALESCE(NEW, OLD);
END; $$;

DROP TRIGGER IF EXISTS trg_apply_expense_stock ON public.expenses;
CREATE TRIGGER trg_apply_expense_stock AFTER INSERT OR DELETE ON public.expenses
FOR EACH ROW EXECUTE FUNCTION public.apply_expense_stock();