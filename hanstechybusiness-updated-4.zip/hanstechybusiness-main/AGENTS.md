<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->
- Multi-tenant: every data table has business_id defaulting to my_business(); RLS scopes all reads/writes to it — why: data isolation between businesses without client-side filtering.
- Staff accounts are created server-side via admin API with business_id/role in app_metadata — why: users cannot self-assign a business.
