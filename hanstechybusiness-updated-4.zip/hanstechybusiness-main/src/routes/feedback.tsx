import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/feedback")({
  head: () => ({
    meta: [
      { title: "Mrejesho — SHOP" },
      { name: "description", content: "Tuma maoni, mapendekezo au changamoto kuhusu mfumo." },
      { property: "og:title", content: "Mrejesho — SHOP" },
      { property: "og:description", content: "Send feedback, ideas or bug reports." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: FeedbackPage,
});

const KINDS = [
  { v: "idea", sw: "Wazo jipya", en: "Idea" },
  { v: "bug", sw: "Changamoto / Kosa", en: "Bug / Problem" },
  { v: "general", sw: "Ushauri wa jumla", en: "General" },
] as const;

function FeedbackPage() {
  const { lang } = useI18n();
  const sw = lang === "sw";
  const { isManager, user } = useAuth();
  const qc = useQueryClient();
  const [kind, setKind] = useState<string>("idea");
  const [message, setMessage] = useState("");

  const { data: list = [] } = useQuery({
    queryKey: ["feedback"],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.from("feedback").select("*").order("created_at", { ascending: false }).limit(200);
      if (error) throw error;
      return data ?? [];
    },
  });

  const send = useMutation({
    mutationFn: async () => {
      const msg = message.trim();
      if (!msg) throw new Error(sw ? "Andika ujumbe" : "Write a message");
      const { error } = await supabase.from("feedback").insert({ kind, message: msg.slice(0, 2000) });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success(sw ? "Asante! Maoni yametumwa." : "Thanks! Feedback sent.");
      setMessage("");
      void qc.invalidateQueries({ queryKey: ["feedback"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const del = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("feedback").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["feedback"] }),
  });

  const label = (v: string) => KINDS.find((k) => k.v === v)?.[sw ? "sw" : "en"] ?? v;

  return (
    <AppShell title={sw ? "Mrejesho" : "Feedback"}>
      <div className="mx-auto max-w-xl space-y-6">
        <div className="stat-card space-y-4">
          <h2 className="text-lg font-bold">{sw ? "Tuma maoni yako" : "Send feedback"}</h2>
          <div className="flex flex-wrap gap-2">
            {KINDS.map((k) => (
              <Button key={k.v} type="button" size="sm" variant={kind === k.v ? "default" : "secondary"} onClick={() => setKind(k.v)}>
                {sw ? k.sw : k.en}
              </Button>
            ))}
          </div>
          <div className="space-y-1.5">
            <Label>{sw ? "Ujumbe" : "Message"}</Label>
            <Textarea rows={5} maxLength={2000} value={message} onChange={(e) => setMessage(e.target.value)} />
          </div>
          <Button className="h-11 w-full" disabled={send.isPending} onClick={() => send.mutate()}>
            {sw ? "Tuma" : "Send"}
          </Button>
        </div>

        <div className="space-y-2">
          <h3 className="font-bold">{isManager ? (sw ? "Maoni yote" : "All feedback") : sw ? "Maoni yako" : "Your feedback"}</h3>
          {list.length === 0 && <p className="text-sm text-muted-foreground">{sw ? "Bado hakuna maoni." : "No feedback yet."}</p>}
          {list.map((f) => (
            <div key={f.id} className="stat-card flex items-start gap-3">
              <div className="flex-1">
                <p className="text-xs font-semibold text-primary">
                  {label(f.kind)} · {new Date(f.created_at).toLocaleString()}
                </p>
                <p className="mt-1 whitespace-pre-wrap text-sm">{f.message}</p>
              </div>
              {isManager && (
                <Button size="icon" variant="ghost" className="text-destructive" onClick={() => del.mutate(f.id)} aria-label="Delete">
                  <Trash2 className="size-4" />
                </Button>
              )}
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
