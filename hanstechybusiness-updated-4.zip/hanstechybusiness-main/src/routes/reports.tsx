import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Guard } from "@/components/Guard";
import { StatCard } from "@/components/StatCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  downloadCsv,
  fetchCustomers,
  fetchExpenses,
  fetchPayments,
  fetchProducts,
  fetchPurchases,
  fetchSales,
  fetchSettings,
  qk,
} from "@/lib/data";
import { dateOnly, dateTime, money, num, rangeBounds, type RangeKey } from "@/lib/format";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/reports")({
  head: () => ({
    meta: [
      { title: "Ripoti — SHOP" },
      { name: "description", content: "Ripoti za mauzo, faida, matumizi, stoo, madeni na mizigo." },
      { property: "og:title", content: "Ripoti — SHOP" },
      { property: "og:description", content: "Sales, profit, expenses, stock, debt and purchase reports." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => {
    const { t } = useI18n();
    return (
      <Guard area="reports" title={t("reports")}>
        <ReportsPage />
      </Guard>
    );
  },
});

type Tab = "salesReport" | "profitReport" | "expenseReport" | "stockReport" | "debtReport" | "purchaseReport" | "paymentReport";
const TABS: Tab[] = ["salesReport", "profitReport", "expenseReport", "stockReport", "debtReport", "purchaseReport", "paymentReport"];

function ReportsPage() {
  const { t } = useI18n();
  const [range, setRange] = useState<RangeKey>("month");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [tab, setTab] = useState<Tab>("salesReport");

  const { data: settings } = useQuery({ queryKey: qk.settings, queryFn: fetchSettings });
  const { data: sales = [] } = useQuery({ queryKey: qk.sales, queryFn: fetchSales });
  const { data: expenses = [] } = useQuery({ queryKey: qk.expenses, queryFn: fetchExpenses });
  const { data: products = [] } = useQuery({ queryKey: qk.products, queryFn: fetchProducts });
  const { data: customers = [] } = useQuery({ queryKey: qk.customers, queryFn: fetchCustomers });
  const { data: purchases = [] } = useQuery({ queryKey: qk.purchases, queryFn: fetchPurchases });
  const { data: payments = [] } = useQuery({ queryKey: qk.payments, queryFn: fetchPayments });
  const cur = settings?.currency ?? "TZS";

  const { start, end } = rangeBounds(range, from, to);
  const inRange = (d: string) => {
    const x = new Date(d);
    return x >= start && x <= end;
  };

  const s = sales.filter((x) => inRange(x.created_at));
  const e = expenses.filter((x) => inRange(x.expense_date));
  const pu = purchases.filter((x) => inRange(x.purchase_date ?? x.created_at));
  const pa = payments.filter((x) => inRange(x.created_at));

  const revenue = s.reduce((a, x) => a + Number(x.total), 0);
  const cogs = s.reduce((a, x) => a + Number(x.cost_total), 0);
  const gross = revenue - cogs;
  const expTotal = e.reduce((a, x) => a + Number(x.amount), 0);
  const net = gross - expTotal;

  const debts = useMemo(() => {
    const m = new Map<string, number>();
    for (const x of sales) if (x.customer_id && Number(x.balance) > 0) m.set(x.customer_id, (m.get(x.customer_id) ?? 0) + Number(x.balance));
    return customers.filter((c) => m.has(c.id)).map((c) => ({ ...c, debt: m.get(c.id)! }));
  }, [sales, customers]);

  const buildTable = (k: Tab): { head: string[]; rows: (string | number)[][] } => {
    switch (k) {
      case "salesReport":
        return {
          head: [t("receiptNo"), t("date"), t("customer"), t("total"), t("paid"), t("balance")],
          rows: s.map((x) => [x.receipt_no, dateTime(x.created_at), x.customer_name ?? t("walkIn"), x.total, x.paid, x.balance]),
        };
      case "profitReport":
        return {
          head: [t("receiptNo"), t("date"), t("revenue"), t("cogs"), t("profit")],
          rows: s.map((x) => [x.receipt_no, dateTime(x.created_at), x.total, x.cost_total, x.profit]),
        };
      case "expenseReport":
        return {
          head: [t("date"), t("category"), t("description"), t("amount")],
          rows: e.map((x) => [dateOnly(x.expense_date), t(x.category), x.description ?? "", x.amount]),
        };
      case "stockReport":
        return {
          head: [t("product"), t("quantity"), t("costPrice"), t("sellingPrice"), t("stockValue")],
          rows: products.filter((p) => p.item_type !== "service").map((p) => [p.name, p.quantity, p.cost_price, p.selling_price, p.quantity * p.cost_price]),
        };
      case "debtReport":
        return {
          head: [t("customer"), t("phone"), t("outstanding")],
          rows: debts.map((c) => [c.name, c.phone ?? "", c.debt]),
        };
      case "purchaseReport":
        return {
          head: [t("date"), t("supplier"), t("goodsCost"), t("otherCosts"), t("totalCost")],
          rows: pu.map((x) => [dateOnly(x.purchase_date ?? x.created_at), x.supplier_name ?? "", x.goods_cost, x.other_costs, x.total_cost]),
        };
      case "paymentReport":
        return {
          head: [t("date"), t("amount"), t("paymentMethod"), t("servedBy")],
          rows: pa.map((x) => [dateTime(x.created_at), x.amount, t(x.method), x.received_by_name ?? ""]),
        };
    }
  };
  const table = buildTable(tab);
  const [full, setFull] = useState(false);
  const period = `${dateOnly(start)} – ${dateOnly(end)}`;
  const summaryRows: (string | number)[][] = [
    [t("revenue"), revenue],
    [t("cogs"), cogs],
    [t("grossProfit"), gross],
    [t("expenses"), expTotal],
    [t("netProfit"), net],
  ];
  const downloadFull = () => {
    const out: (string | number)[][] = [
      [settings?.name ?? ""],
      ...(settings?.tin ? [["TIN", settings.tin]] : []),
      [t("fullReport"), period],
      [],
      [t("summary")],
      ...summaryRows,
    ];
    for (const k of TABS) {
      const tb = buildTable(k);
      out.push([], [t(k)], tb.head, ...tb.rows);
    }
    downloadCsv(`ripoti-kamili-${new Date().toISOString().slice(0, 10)}.csv`, out);
  };
  const printFull = () => {
    setFull(true);
    setTimeout(() => {
      window.print();
      setFull(false);
    }, 300);
  };

  const isMoneyCol = (h: string) =>
    [t("total"), t("paid"), t("balance"), t("revenue"), t("cogs"), t("profit"), t("amount"), t("costPrice"), t("sellingPrice"), t("stockValue"), t("outstanding"), t("goodsCost"), t("otherCosts"), t("totalCost")].includes(h);

  return (
    <div className="space-y-5">
      <div className="no-print flex flex-wrap items-end gap-2">
        {(["today", "week", "month", "year", "custom"] as RangeKey[]).map((r) => (
          <Button key={r} size="sm" variant={range === r ? "default" : "outline"} onClick={() => setRange(r)}>
            {t(r)}
          </Button>
        ))}
        {range === "custom" && (
          <>
            <Input type="date" className="w-40" value={from} onChange={(x) => setFrom(x.target.value)} />
            <Input type="date" className="w-40" value={to} onChange={(x) => setTo(x.target.value)} />
          </>
        )}
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        <StatCard label={t("revenue")} value={money(revenue, cur)} />
        <StatCard label={t("cogs")} value={money(cogs, cur)} />
        <StatCard label={t("grossProfit")} value={money(gross, cur)} tone="profit" />
        <StatCard label={t("expenses")} value={money(expTotal, cur)} tone="debt" />
        <StatCard label={t("netProfit")} value={money(net, cur)} tone={net >= 0 ? "profit" : "debt"} />
      </div>

      <div className="no-print flex flex-wrap gap-2">
        {TABS.map((x) => (
          <Button key={x} size="sm" variant={tab === x ? "secondary" : "ghost"} onClick={() => setTab(x)}>
            {t(x)}
          </Button>
        ))}
      </div>

      <div className="no-print stat-card flex flex-wrap items-center gap-2">
        <span className="mr-auto font-semibold">{t("fullReport")}</span>
        <Button onClick={printFull}>{t("fullReport")} PDF</Button>
        <Button variant="secondary" onClick={downloadFull}>{t("fullReport")} Excel/CSV</Button>
      </div>

      <div className="no-print flex gap-2">
        <Button variant="outline" onClick={() => downloadCsv(`${tab}.csv`, [table.head, ...table.rows])}>
          {t("exportCsv")}
        </Button>
        <Button variant="outline" onClick={() => window.print()}>{t("exportPdf")}</Button>
      </div>

      {full ? (
        <div className="space-y-4">
          <div className="text-center">
            {settings?.logo_url ? <img src={settings.logo_url} alt="" className="mx-auto mb-2 h-16 object-contain" /> : null}
            <p className="text-xl font-extrabold">{settings?.name}</p>
            <p className="text-xs text-muted-foreground">
              {[settings?.phone, settings?.email, settings?.tin ? `TIN: ${settings.tin}` : ""].filter(Boolean).join(" · ")}
            </p>
            <p className="mt-1 font-semibold">{t("fullReport")} · {period}</p>
          </div>
          {TABS.map((k) => (
            <ReportTable key={k} title={t(k)} period={period} table={buildTable(k)} isMoneyCol={isMoneyCol} cur={cur} noData={t("noData")} />
          ))}
        </div>
      ) : (
        <ReportTable title={t(tab)} period={period} table={table} isMoneyCol={isMoneyCol} cur={cur} noData={t("noData")} />
      )}
    </div>
  );
}

function ReportTable({
  title,
  period,
  table,
  isMoneyCol,
  cur,
  noData,
}: {
  title: string;
  period: string;
  table: { head: string[]; rows: (string | number)[][] };
  isMoneyCol: (h: string) => boolean;
  cur: string;
  noData: string;
}) {
  return (
    <div className="stat-card overflow-x-auto p-0" style={{ breakInside: "avoid" }}>
      <h2 className="p-3 font-semibold">{title} · {period}</h2>
      {table.rows.length === 0 ? (
        <p className="p-3 text-sm text-muted-foreground">{noData}</p>
      ) : (
        <table className="w-full text-sm">
          <thead className="border-y text-left text-muted-foreground">
            <tr>{table.head.map((h) => <th key={h} className="p-3">{h}</th>)}</tr>
          </thead>
          <tbody>
            {table.rows.map((r, i) => (
              <tr key={i} className="border-b last:border-0">
                {r.map((c, j) => (
                  <td key={j} className={isMoneyCol(table.head[j] ?? "") ? "num p-3 text-right" : "p-3"}>
                    {isMoneyCol(table.head[j] ?? "") ? money(Number(c), cur) : typeof c === "number" ? num(c) : c}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
