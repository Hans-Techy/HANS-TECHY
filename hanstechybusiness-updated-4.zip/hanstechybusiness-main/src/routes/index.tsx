import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { AlertTriangle, PackageX } from "lucide-react";
import { Guard } from "@/components/Guard";
import { StatCard } from "@/components/StatCard";
import { fetchExpenses, fetchProducts, fetchSales, fetchSettings, qk, type Product, type Sale } from "@/lib/data";
import { money, rangeBounds } from "@/lib/format";
import { useI18n } from "@/lib/i18n";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashibodi — SHOP" },
      {
        name: "description",
        content: "Muhtasari wa mauzo, faida, madeni na bidhaa za biashara yako kwa siku, wiki na mwaka.",
      },
      { property: "og:title", content: "Dashibodi — SHOP" },
      {
        property: "og:description",
        content: "Daily, weekly, monthly and yearly sales and profit at a glance.",
      },
    ],
  }),
  component: DashboardPage,
});

function sum(list: Sale[], field: "total" | "profit" | "paid" | "balance") {
  return list.reduce((a, s) => a + Number(s[field] ?? 0), 0);
}

function within(sales: Sale[], key: "today" | "week" | "month" | "year") {
  const { start, end } = rangeBounds(key);
  return sales.filter((s) => {
    const d = new Date(s.created_at);
    return d >= start && d <= end;
  });
}

function DashboardPage() {
  const { t, lang } = useI18n();
  const { can } = useAuth();
  const showNet = can("expenses");
  const { data: settings } = useQuery({ queryKey: qk.settings, queryFn: fetchSettings });
  const { data: sales = [] } = useQuery({ queryKey: qk.sales, queryFn: fetchSales });
  const { data: products = [] } = useQuery({ queryKey: qk.products, queryFn: fetchProducts });
  const currency = settings?.currency ?? "TZS";

  const today = within(sales, "today");
  // Expenses come out of today's sales (shown only to roles that may see expenses).
  const { data: expenses = [] } = useQuery({ queryKey: qk.expenses, queryFn: fetchExpenses, enabled: showNet });
  const todayStr = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  const spentToday = (expenses as unknown as { amount: number; category: string; expense_date: string }[])
    .filter((e) => e.expense_date === todayStr && e.category !== "stock_usage")
    .reduce((a, e) => a + Number(e.amount), 0);
  const leftToday = sum(today, "paid") - spentToday;
  const week = within(sales, "week");
  const month = within(sales, "month");
  const year = within(sales, "year");

  const lowStock = products.filter((p: Product) => p.item_type !== "service" && p.quantity > 0 && p.quantity <= p.reorder_level);
  const outStock = products.filter((p: Product) => p.item_type !== "service" && p.quantity <= 0);

  const chartData = useMemo(() => {
    const days: { label: string; sales: number; profit: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const start = new Date(d);
      start.setHours(0, 0, 0, 0);
      const end = new Date(d);
      end.setHours(23, 59, 59, 999);
      const daily = sales.filter((s) => {
        const sd = new Date(s.created_at);
        return sd >= start && sd <= end;
      });
      days.push({
        label: d.toLocaleDateString("en-GB", { weekday: "short" }),
        sales: sum(daily, "total"),
        profit: sum(daily, "profit"),
      });
    }
    return days;
  }, [sales]);

  return (
    <Guard area="dashboard" title={t("dashboard")}>
      <div className="space-y-5">
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <StatCard label={t("salesToday")} value={money(sum(today, "total"), currency)} hint={`${today.length} ${t("transactions")}`} />
          <StatCard label={t("salesWeek")} value={money(sum(week, "total"), currency)} />
          <StatCard label={t("salesMonth")} value={money(sum(month, "total"), currency)} />
          <StatCard label={t("salesYear")} value={money(sum(year, "total"), currency)} />
          {showNet && (
            <StatCard
              label={lang === "sw" ? "Kilichobaki leo (baada ya matumizi)" : "Left today (after expenses)"}
              value={money(leftToday, currency)}
              hint={`${lang === "sw" ? "Matumizi" : "Expenses"}: ${money(spentToday, currency)}`}
              tone={leftToday < 0 ? "debt" : "profit"}
            />
          )}
          <StatCard label={t("profitToday")} value={money(sum(today, "profit"), currency)} tone="profit" />
          <StatCard label={t("profitMonth")} value={money(sum(month, "profit"), currency)} tone="profit" />
          <StatCard label={t("profitYear")} value={money(sum(year, "profit"), currency)} tone="profit" />
          <StatCard label={t("totalPaid")} value={money(sum(sales, "paid"), currency)} />
          <StatCard label={t("totalDebt")} value={money(sum(sales, "balance"), currency)} tone="debt" />
          <StatCard label={t("productsInStock")} value={String(products.length)} />
          <StatCard label={t("lowStock")} value={String(lowStock.length)} tone="warn" />
          <StatCard label={t("outOfStock")} value={String(outStock.length)} tone="debt" />
        </div>

        <div className="stat-card">
          <p className="text-sm font-bold">{t("salesTrend")}</p>
          <div className="mt-4 h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 12 }} stroke="var(--color-muted-foreground)" />
                <YAxis tick={{ fontSize: 11 }} stroke="var(--color-muted-foreground)" width={60} />
                <Tooltip
                  formatter={(v: number) => money(v, currency)}
                  contentStyle={{
                    background: "var(--color-card)",
                    border: "1px solid var(--color-border)",
                    borderRadius: 12,
                  }}
                />
                <Legend />
                <Bar dataKey="sales" name={t("sales")} fill="var(--color-chart-1)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="profit" name={t("profit")} fill="var(--color-chart-2)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {(lowStock.length > 0 || outStock.length > 0) && (
          <div className="stat-card">
            <div className="flex items-center justify-between">
              <p className="flex items-center gap-2 text-sm font-bold">
                <AlertTriangle className="size-4 text-warn" />
                {t("stockAlert")}
              </p>
              <Link to="/stock" className="text-xs font-semibold text-primary hover:underline">
                {t("viewAll")}
              </Link>
            </div>
            <ul className="mt-3 divide-y divide-border">
              {[...outStock, ...lowStock].slice(0, 8).map((p) => (
                <li key={p.id} className="flex items-center justify-between py-2.5 text-sm">
                  <span className="flex items-center gap-2 font-medium">
                    {p.quantity <= 0 ? (
                      <PackageX className="size-4 text-debt" />
                    ) : (
                      <AlertTriangle className="size-4 text-warn" />
                    )}
                    {p.name}
                  </span>
                  <span className={`num font-bold ${p.quantity <= 0 ? "text-debt" : "text-warn"}`}>
                    {p.quantity} {p.unit} {t("left")}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </Guard>
  );
}
