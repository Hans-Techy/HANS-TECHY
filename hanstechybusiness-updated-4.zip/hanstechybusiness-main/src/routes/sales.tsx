import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Minus, Pencil, Plus, Search, Trash2 } from "lucide-react";
import { EditSaleDialog } from "@/components/EditSaleDialog";
import { toast } from "sonner";
import { Guard } from "@/components/Guard";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import {
  fetchCustomers,
  fetchProducts,
  fetchSales,
  fetchSettings,
  qk,
  type Product,
} from "@/lib/data";
import { dateTime, money } from "@/lib/format";
import { useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/sales")({
  head: () => ({
    meta: [
      { title: "Mauzo — SHOP" },
      {
        name: "description",
        content: "Uza bidhaa, hesabu jumla na salio, pokea malipo na tengeneza risiti papo hapo.",
      },
      { property: "og:title", content: "Mauzo — SHOP" },
      { property: "og:description", content: "Sell products, take payment and print receipts." },
    ],
  }),
  component: SalesPage,
});

type CartLine = { product: Product; qty: string; price: string };

function SalesPage() {
  const { t } = useI18n();
  return (
    <Guard area="sales" title={t("sales")}>
      <Tabs defaultValue="new">
        <TabsList className="mb-4 grid w-full grid-cols-2">
          <TabsTrigger value="new">{t("newSale")}</TabsTrigger>
          <TabsTrigger value="history">{t("salesHistory")}</TabsTrigger>
        </TabsList>
        <TabsContent value="new">
          <NewSale />
        </TabsContent>
        <TabsContent value="history">
          <History />
        </TabsContent>
      </Tabs>
    </Guard>
  );
}

function NewSale() {
  const { t, lang } = useI18n();
  const { user, fullName, isManager } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();

  const { data: settings } = useQuery({ queryKey: qk.settings, queryFn: fetchSettings });
  const { data: products = [] } = useQuery({ queryKey: qk.products, queryFn: fetchProducts });
  const { data: customers = [] } = useQuery({ queryKey: qk.customers, queryFn: fetchCustomers });
  const currency = settings?.currency ?? "TZS";

  const [search, setSearch] = useState("");
  const [lines, setLines] = useState<CartLine[]>([]);
  const [discountStr, setDiscountStr] = useState("");
  const [instant, setInstant] = useState(false);
  const discount = Number(discountStr) || 0;
  const [paidInput, setPaidInput] = useState("");
  const [method, setMethod] = useState("cash");
  const [customerId, setCustomerId] = useState("walkin");
  const [newName, setNewName] = useState("");
  const [newPhone, setNewPhone] = useState("");

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return products.slice(0, 12);
    return products
      .filter((p) => p.name.toLowerCase().includes(q) || (p.sku ?? "").toLowerCase().includes(q))
      .slice(0, 20);
  }, [products, search]);

  const subtotal = lines.reduce((a, l) => a + (Number(l.qty) || 0) * (Number(l.price) || 0), 0);
  const total = Math.max(0, subtotal - discount);
  const paid = paidInput === "" ? 0 : Number(paidInput);
  const balance = Math.max(0, total - paid);

  const addLine = (p: Product) => {
    setLines((prev) => {
      const existing = prev.find((l) => l.product.id === p.id);
      if (existing) {
        return prev.map((l) => (l.product.id === p.id ? { ...l, qty: String((Number(l.qty) || 0) + 1) } : l));
      }
      return [...prev, { product: p, qty: "1", price: String(Number(p.selling_price)) }];
    });
  };

  // Values stay as raw strings so the field can be cleared and retyped freely.
  const setQty = (id: string, qty: string) =>
    setLines((prev) => prev.map((l) => (l.product.id === id ? { ...l, qty: qty.replace("-", "") } : l)));
  const setPrice = (id: string, price: string) =>
    setLines((prev) => prev.map((l) => (l.product.id === id ? { ...l, price: price.replace("-", "") } : l)));
  const fixQty = (id: string) =>
    setLines((prev) => prev.map((l) => (l.product.id === id && !(Number(l.qty) > 0) ? { ...l, qty: "1" } : l)));
  const remove = (id: string) => setLines((prev) => prev.filter((l) => l.product.id !== id));

  const complete = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("No session");
      if (lines.length === 0) throw new Error(t("emptyCart"));

      for (const l of lines) {
        if (l.product.item_type !== "service" && !(Number(l.qty) > 0)) {
          throw new Error(`${t("quantity")}: ${l.product.name}`);
        }
        if (l.product.item_type !== "service" && Number(l.qty) > Number(l.product.quantity)) {
          throw new Error(`${t("insufficientStock")}: ${l.product.name}`);
        }
      }

      let finalCustomerId: string | null = customerId === "walkin" ? null : customerId;
      let customerName = t("walkIn");
      let customerPhone: string | null = null;

      if (customerId === "new") {
        if (!newName.trim()) throw new Error(t("customerName"));
        const { data, error } = await supabase
          .from("customers")
          .insert({ name: newName.trim(), phone: newPhone.trim() || null })
          .select()
          .single();
        if (error) throw error;
        finalCustomerId = data.id;
        customerName = data.name;
        customerPhone = data.phone;
      } else if (finalCustomerId) {
        const c = customers.find((x) => x.id === finalCustomerId);
        customerName = c?.name ?? "";
        customerPhone = c?.phone ?? null;
      }

      if (balance > 0 && !finalCustomerId) {
        throw new Error(
          lang === "sw"
            ? "Chagua mteja ili kurekodi deni."
            : "Select a customer to record the debt.",
        );
      }

      const costTotal = lines.reduce((a, l) => a + (Number(l.qty) || 0) * Number(l.product.cost_price), 0);
      const profit = total - costTotal;

      const { data: sale, error } = await supabase
        .from("sales")
        .insert({
          customer_id: finalCustomerId,
          customer_name: customerName,
          customer_phone: customerPhone,
          subtotal,
          discount,
          total,
          paid: Math.min(paid, total),
          balance,
          cost_total: costTotal,
          profit,
          payment_method: method as "cash",
          sold_by: user.id,
          sold_by_name: fullName || user.email || "",
        })
        .select()
        .single();
      if (error) throw error;

      const { error: itemsError } = await supabase.from("sale_items").insert(
        lines.map((l) => ({
          sale_id: sale.id,
          product_id: l.product.id,
          product_name: l.product.name,
          quantity: Number(l.qty),
          unit_price: Number(l.price) || 0,
          unit_cost: Number(l.product.cost_price),
          total: Number(l.qty) * (Number(l.price) || 0),
        })),
      );
      if (itemsError) throw itemsError;
      return sale.id as string;
    },
    onSuccess: (id) => {
      toast.success(t("saleComplete"));
      setLines([]);
      setDiscountStr("");
      setPaidInput("");
      setCustomerId("walkin");
      setNewName("");
      setNewPhone("");
      void qc.invalidateQueries({ queryKey: qk.products });
      void qc.invalidateQueries({ queryKey: qk.sales });
      void qc.invalidateQueries({ queryKey: qk.customers });
      void navigate({ to: "/receipt/$id", params: { id } });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : t("error")),
  });

  const quick = useMutation({
    mutationFn: async (p: Product) => {
      if (!user) throw new Error("No session");
      if (p.item_type !== "service" && Number(p.quantity) < 1) throw new Error(`${t("insufficientStock")}: ${p.name}`);
      const price = Number(p.selling_price);
      const cost = Number(p.cost_price);
      const { data: sale, error } = await supabase
        .from("sales")
        .insert({
          customer_id: null,
          customer_name: t("walkIn"),
          customer_phone: null,
          subtotal: price,
          discount: 0,
          total: price,
          paid: price,
          balance: 0,
          cost_total: cost,
          profit: price - cost,
          payment_method: "cash",
          sold_by: user.id,
          sold_by_name: fullName || user.email || "",
        })
        .select()
        .single();
      if (error) throw error;
      const { error: itemError } = await supabase.from("sale_items").insert({
        sale_id: sale.id,
        product_id: p.id,
        product_name: p.name,
        quantity: 1,
        unit_price: price,
        unit_cost: cost,
        total: price,
      });
      if (itemError) throw itemError;
      return sale.id as string;
    },
    onSuccess: (id) => {
      toast.success(t("saleComplete"));
      void qc.invalidateQueries({ queryKey: qk.products });
      void qc.invalidateQueries({ queryKey: qk.sales });
      void navigate({ to: "/receipt/$id", params: { id } });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : t("error")),
  });

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_380px]">
      <div className="stat-card">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t("selectProduct")}
            className="h-12 pl-9"
          />
        </div>
        <label className="mt-3 flex items-center justify-between gap-3 rounded-xl border border-border bg-secondary/60 px-3 py-2.5">
          <span className="text-sm">
            <span className="font-semibold">{lang === "sw" ? "Risiti papo hapo" : "Instant receipt"}</span>
            <span className="block text-xs text-muted-foreground">
              {lang === "sw" ? "Gusa bidhaa: inauzwa 1, cash, risiti inatoka" : "Tap a product: sells 1 for cash and opens the receipt"}
            </span>
          </span>
          <Switch checked={instant} onCheckedChange={setInstant} />
        </label>
        <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
          {filtered.map((p) => (
            <button
              key={p.id}
              onClick={() => (instant ? quick.mutate(p) : addLine(p))}
              className="rounded-xl border border-border bg-secondary p-3 text-left transition-colors hover:bg-accent active:scale-[0.98] disabled:opacity-40"
              disabled={(p.item_type !== "service" && Number(p.quantity) <= 0) || quick.isPending}
            >
              <p className="truncate text-sm font-semibold">{p.name}</p>
              <p className="num mt-1 text-sm font-bold text-primary">{money(p.selling_price, currency)}</p>
              <p className="mt-0.5 text-[11px] text-muted-foreground">
                {p.item_type === "service" ? t("service") : `${Number(p.quantity)} ${p.unit} ${t("left")}`}
              </p>
            </button>
          ))}
          {filtered.length === 0 && (
            <p className="col-span-full py-6 text-center text-sm text-muted-foreground">{t("noData")}</p>
          )}
        </div>
      </div>

      <div className="stat-card space-y-3">
        <p className="text-sm font-bold">
          {t("cart")} · {lines.length} {t("items")}
        </p>

        {lines.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">{t("emptyCart")}</p>
        ) : (
          <ul className="divide-y divide-border">
            {lines.map((l) => (
              <li key={l.product.id} className="py-3">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-sm font-semibold">{l.product.name}</p>
                  <button onClick={() => remove(l.product.id)} aria-label="remove">
                    <Trash2 className="size-4 text-destructive" />
                  </button>
                </div>
                <div className="mt-2 flex items-center gap-2">
                  <Button variant="secondary" size="icon" className="size-9" onClick={() => setQty(l.product.id, String(Math.max(1, (Number(l.qty) || 0) - 1)))}>
                    <Minus className="size-4" />
                  </Button>
                  <Input
                    type="number"
                    inputMode="decimal"
                    value={l.qty}
                    onFocus={(e) => e.target.select()}
                    onBlur={() => fixQty(l.product.id)}
                    onChange={(e) => setQty(l.product.id, e.target.value)}
                    className="num h-9 w-16 text-center"
                  />
                  <Button variant="secondary" size="icon" className="size-9" onClick={() => setQty(l.product.id, String((Number(l.qty) || 0) + 1))}>
                    <Plus className="size-4" />
                  </Button>
                  <Input
                    type="number"
                    inputMode="decimal"
                    value={l.price}
                    disabled={!isManager}
                    onFocus={(e) => e.target.select()}
                    onChange={(e) => setPrice(l.product.id, e.target.value)}
                    className="num h-9 flex-1 text-right"
                  />
                </div>
                <p className="num mt-1.5 text-right text-sm font-bold">{money((Number(l.qty) || 0) * (Number(l.price) || 0), currency)}</p>
              </li>
            ))}
          </ul>
        )}

        <div className="space-y-2 border-t border-border pt-3">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">{t("subtotal")}</span>
            <span className="num font-semibold">{money(subtotal, currency)}</span>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="discount">{t("discount")}</Label>
            <Input
              id="discount"
              type="number"
              inputMode="decimal"
              placeholder="0"
              value={discountStr}
              onFocus={(e) => e.target.select()}
              onChange={(e) => setDiscountStr(e.target.value)}
              className="num h-11 text-right"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="paid">{t("paid")}</Label>
            <Input
              id="paid"
              type="number"
              inputMode="decimal"
              value={paidInput}
              onFocus={(e) => e.target.select()}
              onChange={(e) => setPaidInput(e.target.value)}
              className="num h-11 text-right"
            />
          </div>
          <div className="space-y-1.5">
            <Label>{t("paymentMethod")}</Label>
            <Select value={method} onValueChange={setMethod}>
              <SelectTrigger className="h-11">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="cash">{t("cash")}</SelectItem>
                <SelectItem value="mobile_money">{t("mobile_money")}</SelectItem>
                <SelectItem value="bank">{t("bank")}</SelectItem>
                <SelectItem value="other">{t("other")}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>{t("customer")}</Label>
            <Select value={customerId} onValueChange={setCustomerId}>
              <SelectTrigger className="h-11">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="walkin">{t("walkIn")}</SelectItem>
                <SelectItem value="new">+ {t("newCustomer")}</SelectItem>
                {customers.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name} {c.phone ? `· ${c.phone}` : ""}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {customerId === "new" && (
            <div className="grid grid-cols-2 gap-2">
              <Input
                placeholder={t("customerName")}
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                className="h-11"
              />
              <Input
                placeholder={t("phone")}
                value={newPhone}
                onChange={(e) => setNewPhone(e.target.value)}
                className="h-11"
              />
            </div>
          )}
        </div>

        <div className="rounded-xl bg-secondary p-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold">{t("total")}</span>
            <span className="num text-2xl font-extrabold">{money(total, currency)}</span>
          </div>
          <div className="mt-1 flex items-center justify-between">
            <span className="text-sm text-muted-foreground">{t("balance")}</span>
            <span className={`num text-lg font-bold ${balance > 0 ? "text-debt" : "text-profit"}`}>
              {money(balance, currency)}
            </span>
          </div>
        </div>

        <Button
          className="h-14 w-full text-base font-extrabold"
          disabled={lines.length === 0 || complete.isPending}
          onClick={() => complete.mutate()}
        >
          {t("completeSale")}
        </Button>
      </div>
    </div>
  );
}

function History() {
  const { t } = useI18n();
  const { isAdmin } = useAuth();
  const qc = useQueryClient();
  const { data: settings } = useQuery({ queryKey: qk.settings, queryFn: fetchSettings });
  const { data: sales = [] } = useQuery({ queryKey: qk.sales, queryFn: fetchSales });
  const [q, setQ] = useState("");
  const [toDelete, setToDelete] = useState<(typeof sales)[number] | null>(null);
  const [toEdit, setToEdit] = useState<(typeof sales)[number] | null>(null);
  const currency = settings?.currency ?? "TZS";

  const rows = sales.filter((s) => {
    const needle = q.trim().toLowerCase();
    if (!needle) return true;
    return (
      s.receipt_no.toLowerCase().includes(needle) ||
      (s.customer_name ?? "").toLowerCase().includes(needle) ||
      (s.customer_phone ?? "").includes(needle)
    );
  });

  const del = useMutation({
    mutationFn: async (saleId: string) => {
      const { error } = await supabase.rpc("delete_sale", { p_sale_id: saleId });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success(t("saleDeleted"));
      setToDelete(null);
      void qc.invalidateQueries({ queryKey: qk.sales });
      void qc.invalidateQueries({ queryKey: qk.products });
      void qc.invalidateQueries({ queryKey: qk.payments });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : t("error")),
  });

  return (
    <div className="stat-card">
      <div className="relative mb-3">
        <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("search")} className="h-11 pl-9" />
      </div>
      <ul className="divide-y divide-border">
        {rows.slice(0, 100).map((s) => (
          <li key={s.id} className="flex items-center gap-2">
            <Link
              to="/receipt/$id"
              params={{ id: s.id }}
              className="flex flex-1 items-center justify-between gap-3 py-3 hover:bg-secondary/60"
            >
              <div className="min-w-0">
                <p className="num text-sm font-bold">{s.receipt_no}</p>
                <p className="truncate text-xs text-muted-foreground">
                  {s.customer_name || t("walkIn")} · {dateTime(s.created_at)}
                </p>
              </div>
              <div className="text-right">
                <p className="num text-sm font-bold">{money(s.total, currency)}</p>
                {Number(s.balance) > 0 && (
                  <p className="num text-xs font-semibold text-debt">
                    {t("balance")} {money(s.balance, currency)}
                  </p>
                )}
              </div>
            </Link>
            {isAdmin && (
              <Button variant="ghost" size="icon" className="size-9 shrink-0" aria-label={t("edit")} onClick={() => setToEdit(s)}>
                <Pencil className="size-4" />
              </Button>
            )}
            {isAdmin && (
              <Button
                variant="ghost"
                size="icon"
                className="size-9 shrink-0 text-destructive"
                aria-label={t("deleteSale")}
                onClick={() => setToDelete(s)}
              >
                <Trash2 className="size-4" />
              </Button>
            )}
          </li>
        ))}
        {rows.length === 0 && <li className="py-6 text-center text-sm text-muted-foreground">{t("noData")}</li>}
      </ul>

      <EditSaleDialog sale={toEdit} currency={currency} onClose={() => setToEdit(null)} />
      <AlertDialog open={!!toDelete} onOpenChange={(open) => !open && setToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {t("deleteSale")} · {toDelete?.receipt_no}
            </AlertDialogTitle>
            <AlertDialogDescription>{t("deleteSaleConfirm")}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("cancel")}</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={del.isPending}
              onClick={() => toDelete && del.mutate(toDelete.id)}
            >
              {t("delete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
