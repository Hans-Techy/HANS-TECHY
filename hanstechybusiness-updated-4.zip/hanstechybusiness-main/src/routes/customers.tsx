import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Search } from "lucide-react";
import { toast } from "sonner";
import { Guard } from "@/components/Guard";
import { DeleteButton } from "@/components/DeleteButton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { fetchCustomers, fetchSales, fetchSettings, qk, type Customer } from "@/lib/data";
import { money } from "@/lib/format";
import { useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/customers")({
  head: () => ({
    meta: [
      { title: "Wateja — SHOP" },
      {
        name: "description",
        content: "Wateja wako, manunuzi yao, madeni na kurekodi malipo ya deni kwa urahisi.",
      },
      { property: "og:title", content: "Wateja — SHOP" },
      { property: "og:description", content: "Customers, purchases, debts and debt repayments." },
    ],
  }),
  component: CustomersPage,
});

function CustomersPage() {
  const { t } = useI18n();
  const { user, fullName, isManager } = useAuth();
  const delCustomer = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.rpc("delete_customer", { p_customer_id: id });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success(t("deleted"));
      void qc.invalidateQueries({ queryKey: qk.customers });
      void qc.invalidateQueries({ queryKey: qk.sales });
      void qc.invalidateQueries({ queryKey: qk.payments });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : t("error")),
  });
  const qc = useQueryClient();

  const { data: settings } = useQuery({ queryKey: qk.settings, queryFn: fetchSettings });
  const { data: customers = [] } = useQuery({ queryKey: qk.customers, queryFn: fetchCustomers });
  const { data: sales = [] } = useQuery({ queryKey: qk.sales, queryFn: fetchSales });
  const currency = settings?.currency ?? "TZS";

  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", address: "" });
  const [payFor, setPayFor] = useState<Customer | null>(null);
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("cash");

  const stats = (id: string) => {
    const mine = sales.filter((s) => s.customer_id === id);
    return {
      total: mine.reduce((a, s) => a + Number(s.total), 0),
      paid: mine.reduce((a, s) => a + Number(s.paid), 0),
      debt: mine.reduce((a, s) => a + Number(s.balance), 0),
    };
  };

  const addCustomer = useMutation({
    mutationFn: async () => {
      if (!form.name.trim()) throw new Error(t("customerName"));
      const { data, error } = await supabase
        .from("customers")
        .insert({ name: form.name.trim(), phone: form.phone.trim() || null, address: form.address.trim() || null })
        .select()
        .single();
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success(t("saved"));
      setOpen(false);
      setForm({ name: "", phone: "", address: "" });
      void qc.invalidateQueries({ queryKey: qk.customers });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : t("error")),
  });

  const pay = useMutation({
    mutationFn: async () => {
      if (!user || !payFor) throw new Error("No session");
      const value = Number(amount);
      if (!value || value <= 0) throw new Error(t("amount"));
      const { data, error } = await supabase
        .from("payments")
        .insert({
          customer_id: payFor.id,
          amount: value,
          method: method as "cash",
          received_by: user.id,
          received_by_name: fullName || user.email || "",
        })
        .select()
        .single();
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success(t("saved"));
      setPayFor(null);
      setAmount("");
      void qc.invalidateQueries({ queryKey: qk.sales });
      void qc.invalidateQueries({ queryKey: qk.payments });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : t("error")),
  });

  const rows = customers.filter((c) => {
    const needle = q.trim().toLowerCase();
    if (!needle) return true;
    return c.name.toLowerCase().includes(needle) || (c.phone ?? "").includes(needle);
  });

  const totalDebt = sales.reduce((a, s) => a + Number(s.balance), 0);

  return (
    <Guard area="customers" title={t("customers")}>
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative min-w-[200px] flex-1">
            <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("search")} className="h-11 pl-9" />
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="h-11 font-bold">+ {t("newCustomer")}</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{t("newCustomer")}</DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                <div className="space-y-1.5">
                  <Label>{t("customerName")}</Label>
                  <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="h-11" />
                </div>
                <div className="space-y-1.5">
                  <Label>{t("phone")}</Label>
                  <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="h-11" />
                </div>
                <div className="space-y-1.5">
                  <Label>{t("address")}</Label>
                  <Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className="h-11" />
                </div>
              </div>
              <DialogFooter>
                <Button variant="secondary" onClick={() => setOpen(false)}>
                  {t("cancel")}
                </Button>
                <Button onClick={() => addCustomer.mutate()} disabled={addCustomer.isPending}>
                  {t("save")}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <div className="stat-card flex items-center justify-between">
          <span className="text-sm font-semibold text-muted-foreground">{t("outstanding")}</span>
          <span className="num text-xl font-extrabold text-debt">{money(totalDebt, currency)}</span>
        </div>

        <div className="space-y-3">
          {rows.map((c) => {
            const s = stats(c.id);
            return (
              <div key={c.id} className="stat-card">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-bold">{c.name}</p>
                    <p className="text-xs text-muted-foreground">{c.phone ?? "—"}</p>
                  </div>
                  <div className="flex items-start gap-1">
                  <div className="text-right">
                    <p className="num text-sm">{money(s.total, currency)}</p>
                    <p className={`num text-sm font-bold ${s.debt > 0 ? "text-debt" : "text-profit"}`}>
                      {t("balance")}: {money(s.debt, currency)}
                    </p>
                  </div>
                  {isManager && (
                    <DeleteButton
                      title={t("deleteCustomer")}
                      description={t("deleteCustomerConfirm")}
                      pending={delCustomer.isPending}
                      onConfirm={() => delCustomer.mutate(c.id)}
                    />
                  )}
                  </div>
                </div>
                {s.debt > 0 && (
                  <Button
                    variant="secondary"
                    className="mt-3 h-10 w-full font-semibold"
                    onClick={() => {
                      setPayFor(c);
                      setAmount(String(s.debt));
                    }}
                  >
                    {t("recordPayment")}
                  </Button>
                )}
              </div>
            );
          })}
          {rows.length === 0 && (
            <div className="stat-card text-center text-sm text-muted-foreground">{t("noData")}</div>
          )}
        </div>
      </div>

      <Dialog open={payFor !== null} onOpenChange={(o) => !o && setPayFor(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {t("recordPayment")} · {payFor?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>{t("amount")}</Label>
              <Input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="num h-12 text-right text-lg"
              />
            </div>
            <div className="space-y-1.5">
              <Label>{t("paymentMethod")}</Label>
              <Select value={method} onValueChange={setMethod}>
                <SelectTrigger className="h-11">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">{t("cash")}</SelectItem>
                  <SelectItem value="mobile_money">{t("mobile_money")}</SelectItem>
                  <SelectItem value="bank">{t("bank")}</SelectItem>
                  <SelectItem value="other">{t("other")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setPayFor(null)}>
              {t("cancel")}
            </Button>
            <Button onClick={() => pay.mutate()} disabled={pay.isPending}>
              {t("save")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Guard>
  );
}
