import { createFileRoute, useParams } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Image as ImageIcon, Printer, Share2 } from "lucide-react";
import { toPng } from "html-to-image";
import { Guard } from "@/components/Guard";
import { Button } from "@/components/ui/button";
import { fetchSaleWithItems, fetchSettings, qk } from "@/lib/data";
import { dateTime, money } from "@/lib/format";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/receipt/$id")({
  head: () => ({
    meta: [
      { title: "Risiti — SHOP" },
      { name: "description", content: "Risiti ya mauzo yenye bidhaa, jumla, malipo na salio." },
      { property: "og:title", content: "Risiti — SHOP" },
      { property: "og:description", content: "Sale receipt with items, totals and balance." },
    ],
  }),
  component: ReceiptPage,
});

function ReceiptPage() {
  const { id } = useParams({ from: "/receipt/$id" });
  const { t } = useI18n();
  const { data: settings } = useQuery({ queryKey: qk.settings, queryFn: fetchSettings });
  const { data } = useQuery({ queryKey: ["sale", id], queryFn: () => fetchSaleWithItems(id) });
  const currency = settings?.currency ?? "TZS";
  const sale = data?.sale;
  const items = data?.items ?? [];

  const shareText = sale
    ? [
        `*${settings?.name ?? ""}*`,
        `${t("receiptNo")}: ${sale.receipt_no}`,
        `${t("date")}: ${dateTime(sale.created_at)}`,
        `${t("customer")}: ${sale.customer_name ?? ""}`,
        "",
        ...items.map((i) => `${i.product_name} x${i.quantity} = ${money(i.total, currency)}`),
        "",
        `${t("total")}: ${money(sale.total, currency)}`,
        `${t("paid")}: ${money(sale.paid, currency)}`,
        `${t("balance")}: ${money(sale.balance, currency)}`,
        settings?.receipt_footer ?? "",
      ].join("\n")
    : "";

  return (
    <Guard area="sales" title={t("receipt")}>
      {!sale ? (
        <div className="stat-card text-center text-sm text-muted-foreground">{t("loading")}</div>
      ) : (
        <div className="mx-auto max-w-md space-y-4">
          <div className="stat-card" id="receipt">
            <div className="text-center">
              {settings?.logo_url ? <img src={settings.logo_url} alt="" className="mx-auto mb-2 h-16 object-contain" /> : null}
              <p className="text-lg font-extrabold">{settings?.name}</p>
              {settings?.email ? <p className="text-xs text-muted-foreground">{settings.email}</p> : null}
              {settings?.tin ? <p className="text-xs text-muted-foreground">TIN: {settings.tin}</p> : null}
              <p className="text-xs text-muted-foreground">{settings?.phone}</p>
              <p className="text-xs text-muted-foreground">{settings?.address}</p>
            </div>
            <div className="mt-4 space-y-1 border-y border-dashed border-border py-3 text-xs">
              <Row label={t("receiptNo")} value={sale.receipt_no} />
              <Row label={t("date")} value={dateTime(sale.created_at)} />
              <Row label={t("customer")} value={sale.customer_name || t("walkIn")} />
              {sale.customer_phone ? <Row label={t("phone")} value={sale.customer_phone} /> : null}
              <Row label={t("servedBy")} value={sale.sold_by_name ?? ""} />
            </div>

            <table className="mt-3 w-full text-xs">
              <thead>
                <tr className="text-left text-muted-foreground">
                  <th className="py-1 font-semibold">{t("product")}</th>
                  <th className="py-1 text-center font-semibold">{t("quantity")}</th>
                  <th className="py-1 text-right font-semibold">{t("price")}</th>
                  <th className="py-1 text-right font-semibold">{t("total")}</th>
                </tr>
              </thead>
              <tbody>
                {items.map((i) => (
                  <tr key={i.id} className="border-t border-border">
                    <td className="py-1.5">{i.product_name}</td>
                    <td className="num py-1.5 text-center">{i.quantity}</td>
                    <td className="num py-1.5 text-right">{money(i.unit_price, currency)}</td>
                    <td className="num py-1.5 text-right font-semibold">{money(i.total, currency)}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="mt-3 space-y-1 border-t border-dashed border-border pt-3 text-sm">
              <Row label={t("subtotal")} value={money(sale.subtotal, currency)} />
              <Row label={t("discount")} value={money(sale.discount, currency)} />
              <Row label={t("total")} value={money(sale.total, currency)} bold />
              <Row label={t("paid")} value={money(sale.paid, currency)} />
              <Row label={t("balance")} value={money(sale.balance, currency)} bold />
              <Row label={t("paymentMethod")} value={t(sale.payment_method)} />
            </div>

            <p className="mt-4 text-center text-xs text-muted-foreground">{settings?.receipt_footer}</p>
          </div>

          <div className="no-print grid grid-cols-3 gap-2">
            <Button className="h-12 font-bold" onClick={() => window.print()}>
              <Printer className="size-4" /> PDF
            </Button>
            <Button
              variant="secondary"
              className="h-12 font-bold"
              onClick={async () => {
                const node = document.getElementById("receipt");
                if (!node) return;
                const url = await toPng(node, { pixelRatio: 3, backgroundColor: "#ffffff" });
                const a = document.createElement("a");
                a.href = url;
                a.download = `risiti-${sale.receipt_no}.png`;
                a.click();
              }}
            >
              <ImageIcon className="size-4" /> PNG
            </Button>
            <Button
              variant="secondary"
              className="h-12 font-bold"
              onClick={() =>
                window.open(`https://wa.me/?text=${encodeURIComponent(shareText)}`, "_blank")
              }
            >
              <Share2 className="size-4" /> WhatsApp
            </Button>
          </div>
        </div>
      )}
    </Guard>
  );
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-muted-foreground">{label}</span>
      <span className={`num ${bold ? "font-bold" : ""}`}>{value}</span>
    </div>
  );
}
