import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Badili nenosiri — SHOP" },
      { name: "description", content: "Weka nenosiri jipya la akaunti yako." },
      { property: "og:title", content: "Badili nenosiri — SHOP" },
      { property: "og:description", content: "Set a new password for your account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const { t } = useI18n();
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(t("passwordUpdated"));
    void navigate({ to: "/" });
  };

  return (
    <div className="grid min-h-screen place-items-center bg-background px-4 py-10">
      <form onSubmit={submit} className="w-full max-w-sm space-y-4 rounded-2xl border border-border bg-card p-5 shadow-[var(--shadow-card)]">
        <h1 className="text-xl font-bold">{t("newPassword")}</h1>
        <div className="space-y-1.5">
          <Label htmlFor="pw">{t("newPassword")}</Label>
          <Input id="pw" type="password" autoComplete="new-password" minLength={6} required value={password} onChange={(e) => setPassword(e.target.value)} className="h-12" />
        </div>
        <Button type="submit" disabled={busy} className="h-12 w-full font-bold">
          {t("save")}
        </Button>
      </form>
    </div>
  );
}
