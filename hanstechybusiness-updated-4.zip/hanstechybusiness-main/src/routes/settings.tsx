import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Guard } from "@/components/Guard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { fetchSettings, qk } from "@/lib/data";
import { useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Mipangilio — SHOP" },
      { name: "description", content: "Badilisha jina la biashara, sarafu, risiti na lugha." },
      { property: "og:title", content: "Mipangilio — SHOP" },
      { property: "og:description", content: "Business name, currency, receipt and language settings." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => {
    const { t } = useI18n();
    return (
      <Guard area="settings" title={t("settings")}>
        <SettingsPage />
      </Guard>
    );
  },
});

function SettingsPage() {
  const { t, lang, setLang } = useI18n();
  const { isManager } = useAuth();
  const qc = useQueryClient();
  const { data: settings } = useQuery({ queryKey: qk.settings, queryFn: fetchSettings });
  const [f, setF] = useState({ name: "", phone: "", address: "", currency: "TZS", receipt_footer: "", tin: "", email: "", logo_url: "" });

  useEffect(() => {
    if (settings)
      setF({
        name: settings.name ?? "",
        phone: settings.phone ?? "",
        address: settings.address ?? "",
        currency: settings.currency ?? "TZS",
        receipt_footer: settings.receipt_footer ?? "",
        tin: settings.tin ?? "",
        email: settings.email ?? "",
        logo_url: settings.logo_url ?? "",
      });
  }, [settings]);

  const save = useMutation({
    mutationFn: async () => {
      if (!f.name.trim()) throw new Error(t("businessName"));
      const { error } = await supabase
        .from("businesses")
        .update({ ...f, tin: f.tin || null, email: f.email || null, logo_url: f.logo_url || null, updated_at: new Date().toISOString() })
        .eq("id", settings?.id ?? "");
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success(t("saved"));
      void qc.invalidateQueries({ queryKey: qk.settings });
    },
    onError: (e: Error) => toast.error(e.message || t("error")),
  });

  const field = (key: keyof typeof f, label: string) => (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      <Input value={f[key]} disabled={!isManager} onChange={(e) => setF({ ...f, [key]: e.target.value })} />
    </div>
  );

  return (
    <div className="mx-auto max-w-xl space-y-6">
      <div className="stat-card space-y-3">
        <h2 className="font-semibold">{t("language")}</h2>
        <div className="flex gap-2">
          <Button variant={lang === "sw" ? "default" : "outline"} onClick={() => setLang("sw")}>Kiswahili</Button>
          <Button variant={lang === "en" ? "default" : "outline"} onClick={() => setLang("en")}>English</Button>
        </div>
      </div>
      <div className="stat-card space-y-4">
        {field("name", t("businessName"))}
        {field("phone", t("phone"))}
        {field("address", t("address"))}
        {field("email", t("businessEmail"))}
        {field("tin", t("tin"))}
        <div className="space-y-1.5">
          <Label>{t("logo")}</Label>
          {f.logo_url ? <img src={f.logo_url} alt="logo" className="h-20 rounded-md border border-border bg-card object-contain p-1" /> : null}
          {isManager && (
            <div className="flex flex-wrap gap-2">
              <Input
                type="file"
                accept="image/*"
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  try {
                    setF({ ...f, logo_url: await resizeImage(file, 320) });
                  } catch {
                    toast.error(t("error"));
                  }
                }}
              />
              {f.logo_url && (
                <Button type="button" variant="ghost" onClick={() => setF({ ...f, logo_url: "" })}>
                  {t("removeLogo")}
                </Button>
              )}
            </div>
          )}
        </div>
        {field("currency", t("currency"))}
        {field("receipt_footer", t("receiptFooter"))}
        {isManager && (
          <Button className="w-full" onClick={() => save.mutate()} disabled={save.isPending}>
            {t("save")}
          </Button>
        )}
      </div>
    </div>
  );
}

function resizeImage(file: File, max: number): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.round(img.width * scale);
      c.height = Math.round(img.height * scale);
      const ctx = c.getContext("2d");
      if (!ctx) return reject(new Error("canvas"));
      ctx.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL("image/png"));
    };
    img.onerror = reject;
    img.src = url;
  });
}
