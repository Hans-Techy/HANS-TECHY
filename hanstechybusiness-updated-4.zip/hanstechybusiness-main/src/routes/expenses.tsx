import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Guard } from "@/components/Guard";
import { DeleteButton } from "@/components/DeleteButton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { fetchExpenses, fetchProducts, fetchSales, fetchSettings, qk } from "@/lib/data";
import { dateOnly, money } from "@/lib/format";
import { useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/expenses")({
  head: () => ({
    meta: [
      { title: "Matumizi — SHOP" },
      { name: "description", content: "Rekodi kodi, mishahara, usafiri, umeme na gharama nyingine za biashara." },
      { property: "og:title", content: "Matumizi — SHOP" },
      { property: "og:description", content: "Track rent, salaries, transport, electricity and other costs." },
    ],
  }),
  component: ExpensesPage,
});

// Local calendar date (toISOString alone is UTC and shows "yesterday" after midnight in East Africa).
const localDate = (d = new Date()) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);

const CATEGORIES = ["rent", "salaries", "transport", "electricity", "internet", "other"];

function ExpensesPage() {
  const { t, lang } = useI18n();
  const { user, fullName, isAdmin } = useAuth();
  const qc = useQueryClient();
  const del = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("expenses").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success(t("deleted"));
      void qc.invalidateQueries({ queryKey: qk.expenses });
      void qc.invalidateQueries({ queryKey: qk.products });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : t("error")),
  });

  const { data: settings } = useQuery({ queryKey: qk.settings, queryFn: fetchSettings });
  const { data: expenses = [] } = useQuery({ queryKey: qk.expenses, queryFn: fetchExpenses });
  const currency = settings?.currency ?? "TZS";

  const { data: products = [] } = useQuery({ queryKey: qk.products, queryFn: fetchProducts });
  const stockItems = products.filter((p) => p.item_type !== "service");
  const [mode, setMode] = useState<"cash" | "stock">("cash");
  const [productId, setProductId] = useState("");
  const [qty, setQty] = useState("1");
  const picked = stockItems.find((p) => p.id === productId);
  const [open, setOpen] = useState(false);
  const [category, setCategory] = useState("rent");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [date, setDate] = useState(localDate());

  const save = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("No session");
      let value = Number(amount);
      let extra: { product_id?: string; quantity?: number } = {};
      let desc = description.trim();
      if (mode === "stock") {
        const q = Number(qty);
        if (!picked || !q || q <= 0) throw new Error(t("product"));
        if (q > Number(picked.quantity)) throw new Error(`${t("insufficientStock")}: ${picked.name}`);
        value = q * Number(picked.cost_price);
        extra = { product_id: picked.id, quantity: q };
        desc = `${picked.name} × ${q} ${picked.unit}${desc ? " — " + desc : ""}`;
      }
      if (mode === "cash" && (!value || value <= 0)) throw new Error(t("amount"));
      const { data, error } = await supabase
        .from("expenses")
        .insert({
          category: mode === "stock" ? "stock_usage" : category,
          amount: value,
          description: desc || null,
          ...extra,
          expense_date: date,
          created_by: user.id,
          created_by_name: fullName || user.email || "",
        })
        .select()
        .single();
      if (error) throw error;
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: qk.sales });
      toast.success(t("saved"));
      setOpen(false);
      setAmount("");
      setDescription("");
      setQty("1");
      setProductId("");
      void qc.invalidateQueries({ queryKey: qk.expenses });
      void qc.invalidateQueries({ queryKey: qk.products });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : t("error")),
  });

  // Expenses are paid out of today's sales: cash collected today minus cash expenses dated today.
  const { data: sales = [] } = useQuery({ queryKey: qk.sales, queryFn: fetchSales });
  const todayStr = localDate();
  const collected = sales
    .filter((s) => localDate(new Date(s.created_at)) === todayStr)
    .reduce((a, s) => a + Number(s.paid), 0);
  const spent = (expenses as unknown as { amount: number; category: string; expense_date: string }[])
    .filter((e) => e.expense_date === todayStr && e.category !== "stock_usage")
    .reduce((a, e) => a + Number(e.amount), 0);
  const left = collected - spent;
  const afterThis = left - (date === todayStr ? Number(amount) || 0 : 0);
  const L = (sw: string, en: string) => (lang === "sw" ? sw : en);

  const total = expenses.reduce((a, e) => a + Number((e as { amount: number }).amount), 0);

  return (
    <Guard area="expenses" title={t("expenses")}>
      <div className="space-y-4">
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="h-12 w-full font-bold sm:w-auto">+ {t("newExpense")}</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{t("newExpense")}</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <Button type="button" variant={mode === "cash" ? "default" : "outline"} onClick={() => setMode("cash")}>
                  {t("cashExpense")}
                </Button>
                <Button type="button" variant={mode === "stock" ? "default" : "outline"} onClick={() => setMode("stock")}>
                  {t("stockUsage")}
                </Button>
              </div>
              {mode === "stock" ? (
                <>
                  <p className="text-xs text-muted-foreground">{t("stockUsageHint")}</p>
                  <div className="space-y-1.5">
                    <Label>{t("product")}</Label>
                    <Select value={productId} onValueChange={setProductId}>
                      <SelectTrigger className="h-11">
                        <SelectValue placeholder="—" />
                      </SelectTrigger>
                      <SelectContent>
                        {stockItems.map((p) => (
                          <SelectItem key={p.id} value={p.id}>
                            {p.name} ({Number(p.quantity)} {p.unit})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>{t("quantity")}{picked ? ` (${picked.unit})` : ""}</Label>
                    <Input type="number" step="any" value={qty} onChange={(e) => setQty(e.target.value)} className="num h-12 text-right text-lg" />
                  </div>
                  <div className="flex justify-between rounded-lg bg-secondary p-3 text-sm">
                    <span className="text-muted-foreground">{t("amount")}</span>
                    <span className="num font-bold">{money((Number(qty) || 0) * Number(picked?.cost_price ?? 0), currency)}</span>
                  </div>
                </>
              ) : (
              <>
              <div className="space-y-1.5">
                <Label>{t("category")}</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger className="h-11">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((c) => (
                      <SelectItem key={c} value={c}>
                        {t(c)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>{t("amount")}</Label>
                <Input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="num h-12 text-right text-lg"
                />
              </div>
              <div className={`rounded-lg border p-3 text-sm ${afterThis < 0 ? "border-destructive/40 bg-destructive/10" : "border-border bg-secondary"}`}>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{L("Mauzo ya leo yaliyobaki", "Today's sales available")}</span>
                  <span className="num font-semibold">{money(left, currency)}</span>
                </div>
                <div className="mt-1 flex justify-between">
                  <span className="text-muted-foreground">{L("Itabaki baada ya matumizi haya", "Left after this expense")}</span>
                  <span className={`num font-bold ${afterThis < 0 ? "text-destructive" : ""}`}>{money(afterThis, currency)}</span>
                </div>
                {afterThis < 0 && (
                  <p className="mt-2 text-xs font-semibold text-destructive">
                    {L("Matumizi haya yanazidi mauzo ya leo kwa", "This exceeds today's sales by")} {money(-afterThis, currency)}
                  </p>
                )}
              </div>
              </>
              )}
              <div className="space-y-1.5">
                <Label>{t("description")}</Label>
                <Input value={description} onChange={(e) => setDescription(e.target.value)} className="h-11" />
              </div>
              <div className="space-y-1.5">
                <Label>{t("date")}</Label>
                <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="h-11" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="secondary" onClick={() => setOpen(false)}>
                {t("cancel")}
              </Button>
              <Button onClick={() => save.mutate()} disabled={save.isPending}>
                {t("save")}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <div className="stat-card space-y-2">
          <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">{L("Mauzo ya leo", "Today's sales")}</p>
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">{L("Fedha iliyopatikana (mauzo ya leo)", "Collected from today's sales")}</span>
            <span className="num font-semibold">{money(collected, currency)}</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">{L("Matumizi ya leo", "Today's expenses")}</span>
            <span className="num font-semibold text-destructive">− {money(spent, currency)}</span>
          </div>
          <div className="flex items-center justify-between border-t border-border pt-2">
            <span className="text-sm font-bold">{L("Kilichobaki", "Left")}</span>
            <span className={`num text-xl font-extrabold ${left < 0 ? "text-destructive" : "text-profit"}`}>{money(left, currency)}</span>
          </div>
        </div>

        <div className="stat-card flex items-center justify-between">
          <span className="text-sm font-semibold text-muted-foreground">{t("total")}</span>
          <span className="num text-xl font-extrabold">{money(total, currency)}</span>
        </div>

        <div className="stat-card p-0">
          <ul className="divide-y divide-border">
            {expenses.map((raw) => {
              const e = raw as unknown as {
                id: string;
                category: string;
                description: string | null;
                amount: number;
                expense_date: string;
                created_by_name: string | null;
              };
              return (
                <li key={e.id} className="flex items-center justify-between gap-3 p-3">
                  <div className="min-w-0">
                    <p className="text-sm font-semibold">{t(e.category)}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      {e.description || "—"} · {dateOnly(e.expense_date)} · {e.created_by_name}
                    </p>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="num text-sm font-bold">{money(e.amount, currency)}</span>
                    {isAdmin && (
                      <DeleteButton
                        title={t("deleteExpense")}
                        description={t("deleteExpenseConfirm")}
                        pending={del.isPending}
                        onConfirm={() => del.mutate(e.id)}
                      />
                    )}
                  </div>
                </li>
              );
            })}
            {expenses.length === 0 && (
              <li className="p-6 text-center text-sm text-muted-foreground">{t("noData")}</li>
            )}
          </ul>
        </div>
      </div>
    </Guard>
  );
}
