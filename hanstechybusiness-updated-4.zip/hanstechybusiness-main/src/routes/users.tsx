import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Guard } from "@/components/Guard";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/integrations/supabase/client";
import { qk } from "@/lib/data";
import { useAuth, type Role } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { DeleteButton } from "@/components/DeleteButton";
import { createStaff, deleteStaff } from "@/lib/staff.functions";

export const Route = createFileRoute("/users")({
  head: () => ({
    meta: [
      { title: "Watumiaji — SHOP" },
      { name: "description", content: "Simamia watumiaji, vyeo na ruhusa zao." },
      { property: "og:title", content: "Watumiaji — SHOP" },
      { property: "og:description", content: "Manage users, roles and permissions." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => {
    const { t } = useI18n();
    return (
      <Guard area="users" title={t("users")}>
        <UsersPage />
      </Guard>
    );
  },
});

const ROLES: Role[] = ["admin", "manager", "salesperson", "storekeeper"];

function UsersPage() {
  const { t } = useI18n();
  const { user } = useAuth();
  const qc = useQueryClient();

  const { data: profiles = [] } = useQuery({
    queryKey: qk.profiles,
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("*").order("created_at");
      if (error) throw error;
      return data ?? [];
    },
  });
  const { data: roles = [] } = useQuery({
    queryKey: qk.roles,
    queryFn: async () => {
      const { data, error } = await supabase.from("user_roles").select("*");
      if (error) throw error;
      return data ?? [];
    },
  });
  const setRole = useMutation({
    mutationFn: async ({ userId, role }: { userId: string; role: Role }) => {
      const { error: e1 } = await supabase.from("user_roles").delete().eq("user_id", userId);
      if (e1) throw e1;
      const { error: e2 } = await supabase.from("user_roles").insert({ user_id: userId, role });
      if (e2) throw e2;
    },
    onSuccess: () => {
      toast.success(t("saved"));
      void qc.invalidateQueries({ queryKey: qk.roles });
    },
    onError: (e: Error) => toast.error(e.message || t("error")),
  });

  const updateProfile = useMutation({
    mutationFn: async ({ id, patch }: { id: string; patch: { full_name?: string; phone?: string | null; active?: boolean } }) => {
      const { error } = await supabase.from("profiles").update(patch).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success(t("saved"));
      void qc.invalidateQueries({ queryKey: qk.profiles });
    },
    onError: (e: Error) => toast.error(e.message || t("error")),
  });

  const createFn = useServerFn(createStaff);
  const deleteFn = useServerFn(deleteStaff);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ fullName: "", email: "", password: "", role: "salesperson" as Role });

  const addStaff = useMutation({
    mutationFn: () => createFn({ data: form }),
    onSuccess: () => {
      toast.success(t("staffAdded"));
      setOpen(false);
      setForm({ fullName: "", email: "", password: "", role: "salesperson" });
      void qc.invalidateQueries({ queryKey: qk.profiles });
      void qc.invalidateQueries({ queryKey: qk.roles });
    },
    onError: (e: Error) => toast.error(e.message || t("error")),
  });

  const removeStaff = useMutation({
    mutationFn: (userId: string) => deleteFn({ data: { userId } }),
    onSuccess: () => {
      toast.success(t("deleted"));
      void qc.invalidateQueries({ queryKey: qk.profiles });
    },
    onError: (e: Error) => toast.error(e.message || t("error")),
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="h-11 font-semibold">{t("addStaff")}</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{t("addStaff")}</DialogTitle>
            </DialogHeader>
            <form
              id="staff-form"
              className="space-y-3"
              onSubmit={(e) => {
                e.preventDefault();
                addStaff.mutate();
              }}
            >
              <div className="space-y-1.5">
                <Label>{t("fullName")}</Label>
                <Input required value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} className="h-11" />
              </div>
              <div className="space-y-1.5">
                <Label>{t("email")}</Label>
                <Input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="h-11" />
              </div>
              <div className="space-y-1.5">
                <Label>{t("password")}</Label>
                <Input required minLength={6} type="text" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} className="h-11" />
              </div>
              <div className="space-y-1.5">
                <Label>{t("role")}</Label>
                <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v as Role })}>
                  <SelectTrigger className="h-11"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {ROLES.map((r) => (
                      <SelectItem key={r} value={r}>{t(r)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </form>
            <DialogFooter>
              <Button variant="secondary" onClick={() => setOpen(false)}>{t("cancel")}</Button>
              <Button type="submit" form="staff-form" disabled={addStaff.isPending}>{t("save")}</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      <div className="stat-card overflow-x-auto p-0">
        <table className="w-full text-sm">
          <thead className="border-b text-left text-muted-foreground">
            <tr>
              <th className="p-3">{t("name")}</th>
              <th className="p-3">{t("phone")}</th>
              <th className="p-3">{t("role")}</th>
              <th className="p-3">{t("userActive")}</th>
              <th className="p-3" />
            </tr>
          </thead>
          <tbody>
            {profiles.map((p) => {
              const r = (roles.find((x) => x.user_id === p.id)?.role ?? "salesperson") as Role;
              const self = p.id === user?.id;
              return (
                <tr key={p.id} className={`border-b last:border-0 ${p.active ? "" : "opacity-60"}`}>
                  <td className="p-3">
                    <Input
                      defaultValue={p.full_name}
                      className="h-9 min-w-36"
                      onBlur={(e) => {
                        const v = e.target.value.trim();
                        if (v && v !== p.full_name) updateProfile.mutate({ id: p.id, patch: { full_name: v } });
                      }}
                    />
                  </td>
                  <td className="p-3">
                    <Input
                      defaultValue={p.phone ?? ""}
                      className="h-9 min-w-32"
                      onBlur={(e) => {
                        const v = e.target.value.trim();
                        if (v !== (p.phone ?? "")) updateProfile.mutate({ id: p.id, patch: { phone: v || null } });
                      }}
                    />
                  </td>
                  <td className="p-3">
                    <Select
                      value={r}
                      disabled={self}
                      onValueChange={(v) => setRole.mutate({ userId: p.id, role: v as Role })}
                    >
                      <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {ROLES.map((x) => (
                          <SelectItem key={x} value={x}>{t(x)}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </td>
                  <td className="p-3">
                    <Switch
                      checked={p.active}
                      disabled={self}
                      onCheckedChange={(v) => updateProfile.mutate({ id: p.id, patch: { active: v } })}
                    />
                  </td>
                  <td className="p-3">
                    {!self && (
                      <DeleteButton
                        title={t("deleteUser")}
                        description={t("deleteUserConfirm")}
                        pending={removeStaff.isPending}
                        onConfirm={() => removeStaff.mutate(p.id)}
                      />
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
