import { createFileRoute } from "@tanstack/react-router";

const BASE = `Wewe ni "HANS TECHY", msaidizi rasmi wa mfumo wa SHOP (mfumo wa kusimamia biashara: mauzo, risiti, stoo/huduma, manunuzi, wateja na madeni, mapato, matumizi, ripoti, wafanyakazi, mipangilio, mrejesho).
Jibu kwa Kiswahili kwa chaguo-msingi; kama mtumiaji ameandika Kiingereza, jibu kwa Kiingereza. Toa majibu mafupi, wazi, hatua kwa hatua inapohitajika. Unaweza pia kujibu maswali ya jumla ya biashara na teknolojia.
Kwa maswali kuhusu biashara ya mtumiaji, tumia TAARIFA ZA SASA hapa chini pekee. Usibuni namba. Kama taarifa haipo, sema huna na mwelekeze ukurasa wa kuiona (Ripoti, Stoo, Wateja).`;

const json = (status: number, error: string) =>
  new Response(JSON.stringify({ error }), { status, headers: { "content-type": "application/json" } });

// Best-effort limiter (per server instance): 15 questions per minute per user.
const hits = new Map<string, number[]>();
function limited(id: string) {
  const now = Date.now();
  const recent = (hits.get(id) ?? []).filter((t) => now - t < 60_000);
  recent.push(now);
  hits.set(id, recent);
  return recent.length > 15;
}

const fmt = (n: number) => Math.round(n).toLocaleString("en-US");

// Reads live numbers with the caller's own token, so RLS decides what this user may see.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function snapshot(sb: any, userId: string, offsetMin: number): Promise<string> {
  const shifted = new Date(Date.now() - offsetMin * 60_000);
  shifted.setUTCHours(0, 0, 0, 0);
  const start = new Date(shifted.getTime() + offsetMin * 60_000).toISOString();
  const [biz, roles, today, prods, debts] = await Promise.allSettled([
    sb.from("businesses").select("name,currency").limit(1).maybeSingle(),
    sb.from("user_roles").select("role").eq("user_id", userId),
    sb.from("sales").select("total,paid,balance,profit").gte("created_at", start).limit(2000),
    sb.from("products").select("name,quantity,unit,reorder_level,item_type").limit(1000),
    sb.from("sales").select("customer_name,balance").gt("balance", 0).limit(1000),
  ]);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const get = (r: PromiseSettledResult<any>) => (r.status === "fulfilled" ? r.value.data ?? null : null);
  const b = get(biz);
  const roleList: string[] = (get(roles) ?? []).map((r: { role: string }) => r.role);
  const isMgr = roleList.some((r) => r === "admin" || r === "manager");
  const cur = b?.currency ?? "TZS";
  const lines = [
    "TAARIFA ZA SASA (zimesomwa sasa hivi, kwa ruhusa za mtumiaji huyu):",
    `Biashara: ${b?.name ?? "haijulikani"} (${cur}). Cheo cha mtumiaji: ${roleList.join(", ") || "haijulikani"}.`,
    `Tarehe na saa: ${new Date(Date.now() - offsetMin * 60_000).toISOString().slice(0, 16).replace("T", " ")}.`,
  ];
  const s = get(today) as { total: number; paid: number; balance: number; profit: number }[] | null;
  if (s) {
    const sum = (k: "total" | "paid" | "balance" | "profit") => s.reduce((a, x) => a + Number(x[k] ?? 0), 0);
    lines.push(`Mauzo ya leo: ${s.length}, jumla ${cur} ${fmt(sum("total"))}, yaliyolipwa ${fmt(sum("paid"))}, deni jipya ${fmt(sum("balance"))}${isMgr ? `, faida ${fmt(sum("profit"))}` : ""}.`);
  }
  const p = get(prods) as { name: string; quantity: number; unit: string; reorder_level: number; item_type: string }[] | null;
  if (p) {
    const low = p.filter((x) => x.item_type !== "service" && Number(x.quantity) <= Number(x.reorder_level)).sort((a, c) => Number(a.quantity) - Number(c.quantity));
    lines.push(low.length ? `Bidhaa zinazoisha (${low.length}): ${low.slice(0, 10).map((x) => `${x.name} ${Number(x.quantity)} ${x.unit}`).join("; ")}.` : "Hakuna bidhaa inayoisha.");
  }
  const d = get(debts) as { customer_name: string | null; balance: number }[] | null;
  if (d) {
    const by = new Map<string, number>();
    for (const x of d) by.set(x.customer_name || "Bila jina", (by.get(x.customer_name || "Bila jina") ?? 0) + Number(x.balance));
    const top = [...by.entries()].sort((a, c) => c[1] - a[1]).slice(0, 10);
    lines.push(top.length ? `Madeni ya wateja: jumla ${cur} ${fmt([...by.values()].reduce((a, c) => a + c, 0))}. Wakubwa: ${top.map(([n, v]) => `${n} ${fmt(v)}`).join("; ")}.` : "Hakuna madeni.");
  }
  return lines.join("\n");
}

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const auth = request.headers.get("authorization");
          if (!auth?.startsWith("Bearer ")) return json(401, "Ingia kwanza ili kutumia msaidizi.");
          const url = process.env["SUPABASE_URL"];
          const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
          if (!url || !key) return json(500, "Seva haijaunganishwa na Supabase (SUPABASE_URL / SUPABASE_PUBLISHABLE_KEY).");
          const officialKey = process.env["OPENAI_API_KEY"];
          const gatewayKey = process.env["LOVABLE_API_KEY"];
          if (!officialKey && !gatewayKey) {
            return json(503, "Msaidizi haujawashwa: weka OPENAI_API_KEY (au LOVABLE_API_KEY) kwenye mazingira ya seva.");
          }

          const token = auth.slice(7);
          const { createClient } = await import("@supabase/supabase-js");
          const sb = createClient(url, key, {
            global: { headers: { Authorization: `Bearer ${token}` } },
            auth: { persistSession: false, autoRefreshToken: false },
          });
          const { data, error } = await sb.auth.getUser(token);
          if (error || !data.user) return json(401, "Kikao kimeisha. Ingia tena.");
          const { data: biz } = await sb.rpc("my_business");
          if (!biz) return json(403, "Akaunti hii imezimwa au haina biashara.");
          if (limited(data.user.id)) return json(429, "Maswali mengi ndani ya dakika moja. Subiri kidogo kisha jaribu tena.");

          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          let messages: any;
          try {
            ({ messages } = await request.json());
          } catch {
            return json(400, "Ombi si sahihi.");
          }
          if (!Array.isArray(messages) || messages.length === 0 || messages.length > 40 || JSON.stringify(messages).length > 60_000) {
            return json(400, "Mazungumzo ni marefu mno. Anza mazungumzo mapya.");
          }

          const offset = Number(request.headers.get("x-tz-offset"));
          const context = await snapshot(sb, data.user.id, Number.isFinite(offset) ? offset : -180).catch(() => "");

          const { streamText, convertToModelMessages } = await import("ai");
          const { createOpenAI } = await import("@ai-sdk/openai");
          const official = !!officialKey;
          const openai = official
            ? createOpenAI({ apiKey: officialKey })
            : createOpenAI({
                baseURL: "https://ai.gateway.lovable.dev/v1",
                apiKey: gatewayKey!,
                headers: { "Lovable-API-Key": gatewayKey!, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
              });
          // Set AI_MODEL to switch models without touching code.
          const model = process.env["AI_MODEL"] || (official ? "gpt-5-mini" : "openai/gpt-6-astra");
          const result = streamText({
            model: openai.responses(model),
            system: context ? `${BASE}\n\n${context}` : BASE,
            messages: await convertToModelMessages(messages),
            maxRetries: 1,
            abortSignal: request.signal,
            providerOptions: {
              openai: official
                ? { store: false }
                : { forceReasoning: true, reasoningEffort: "low", store: false, include: ["reasoning.encrypted_content"] },
            },
          });
          return result.toUIMessageStreamResponse({ originalMessages: messages });
        } catch (e) {
          console.error("[api/chat]", e);
          return json(500, "Msaidizi umeshindwa kujibu sasa hivi. Jaribu tena baada ya muda mfupi.");
        }
      },
    },
  },
});
