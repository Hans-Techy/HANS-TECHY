import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Guard } from "@/components/Guard";
import { DeleteButton } from "@/components/DeleteButton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import {
  fetchProducts,
  fetchPurchases,
  fetchSettings,
  fetchSuppliers,
  qk,
  type Product,
} from "@/lib/data";
import { dateOnly, money } from "@/lib/format";
import { useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/purchases")({
  head: () => ({
    meta: [
      { title: "Mizigo — SHOP" },
      {
        name: "description",
        content: "Ingiza mzigo mpya kutoka kwa msambazaji na stoo iongezeke moja kwa moja.",
      },
      { property: "og:title", content: "Mizigo — SHOP" },
      { property: "og:description", content: "Record incoming goods; stock updates automatically." },
    ],
  }),
  component: PurchasesPage,
});

type Line = { product: Product; qty: number; unitCost: number };

function PurchasesPage() {
  const { t } = useI18n();
  const { user, fullName, isAdmin } = useAuth();
  const qc = useQueryClient();
  const delPurchase = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.rpc("delete_purchase", { p_purchase_id: id });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success(t("deleted"));
      void qc.invalidateQueries({ queryKey: qk.purchases });
      void qc.invalidateQueries({ queryKey: qk.products });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : t("error")),
  });

  const { data: settings } = useQuery({ queryKey: qk.settings, queryFn: fetchSettings });
  const { data: products = [] } = useQuery({ queryKey: qk.products, queryFn: fetchProducts });
  const { data: suppliers = [] } = useQuery({ queryKey: qk.suppliers, queryFn: fetchSuppliers });
  const { data: purchases = [] } = useQuery({ queryKey: qk.purchases, queryFn: fetchPurchases });
  const currency = settings?.currency ?? "TZS";

  const [open, setOpen] = useState(false);
  const [supplierId, setSupplierId] = useState("");
  const [newSupplier, setNewSupplier] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [otherCosts, setOtherCosts] = useState("0");
  const [notes, setNotes] = useState("");
  const [lines, setLines] = useState<Line[]>([]);
  const [pick, setPick] = useState("");

  const goodsCost = lines.reduce((a, l) => a + l.qty * l.unitCost, 0);
  const totalCost = goodsCost + (Number(otherCosts) || 0);

  const addLine = (id: string) => {
    const p = products.find((x) => x.id === id);
    if (!p || lines.some((l) => l.product.id === id)) return;
    setLines([...lines, { product: p, qty: 1, unitCost: Number(p.cost_price) }]);
    setPick("");
  };

  const save = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("No session");
      if (lines.length === 0) throw new Error(t("addProduct"));

      let sid: string | null = supplierId || null;
      let sname = suppliers.find((s) => s.id === supplierId)?.name ?? "";
      if (newSupplier.trim()) {
        const { data, error } = await supabase
          .from("suppliers")
          .insert({ name: newSupplier.trim() })
          .select()
          .single();
        if (error) throw error;
        sid = data.id;
        sname = data.name;
      }

      const { data: purchase, error } = await supabase
        .from("purchases")
        .insert({
          supplier_id: sid,
          supplier_name: sname,
          purchase_date: date,
          goods_cost: goodsCost,
          other_costs: Number(otherCosts) || 0,
          total_cost: totalCost,
          notes: notes.trim() || null,
          created_by: user.id,
          created_by_name: fullName || user.email || "",
        })
        .select()
        .single();
      if (error) throw error;

      const { error: itemsError } = await supabase.from("purchase_items").insert(
        lines.map((l) => ({
          purchase_id: purchase.id,
          product_id: l.product.id,
          product_name: l.product.name,
          quantity: l.qty,
          unit_cost: l.unitCost,
          total: l.qty * l.unitCost,
        })),
      );
      if (itemsError) throw itemsError;
    },
    onSuccess: () => {
      toast.success(t("saved"));
      setOpen(false);
      setLines([]);
      setNotes("");
      setOtherCosts("0");
      setNewSupplier("");
      void qc.invalidateQueries({ queryKey: qk.purchases });
      void qc.invalidateQueries({ queryKey: qk.products });
      void qc.invalidateQueries({ queryKey: qk.suppliers });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : t("error")),
  });

  return (
    <Guard area="purchases" title={t("purchases")}>
      <div className="space-y-4">
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="h-12 w-full font-bold sm:w-auto">+ {t("newPurchase")}</Button>
          </DialogTrigger>
          <DialogContent className="max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{t("newPurchase")}</DialogTitle>
            </DialogHeader>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>{t("supplier")}</Label>
                <Select value={supplierId} onValueChange={setSupplierId}>
                  <SelectTrigger className="h-11">
                    <SelectValue placeholder="—" />
                  </SelectTrigger>
                  <SelectContent>
                    {suppliers.map((s) => (
                      <SelectItem key={s.id} value={s.id}>
                        {s.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>+ {t("supplier")}</Label>
                <Input value={newSupplier} onChange={(e) => setNewSupplier(e.target.value)} className="h-11" />
              </div>
              <div className="space-y-1.5">
                <Label>{t("date")}</Label>
                <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="h-11" />
              </div>
              <div className="space-y-1.5">
                <Label>{t("otherCosts")}</Label>
                <Input
                  type="number"
                  value={otherCosts}
                  onChange={(e) => setOtherCosts(e.target.value)}
                  className="num h-11 text-right"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>{t("addProduct")}</Label>
              <Select value={pick} onValueChange={addLine}>
                <SelectTrigger className="h-11">
                  <SelectValue placeholder={t("selectProduct")} />
                </SelectTrigger>
                <SelectContent>
                  {products.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <ul className="divide-y divide-border">
              {lines.map((l) => (
                <li key={l.product.id} className="flex items-center gap-2 py-2">
                  <span className="min-w-0 flex-1 truncate text-sm font-medium">{l.product.name}</span>
                  <Input
                    type="number"
                    value={l.qty}
                    onChange={(e) =>
                      setLines(lines.map((x) => (x.product.id === l.product.id ? { ...x, qty: Number(e.target.value) } : x)))
                    }
                    className="num h-10 w-20 text-center"
                  />
                  <Input
                    type="number"
                    value={l.unitCost}
                    onChange={(e) =>
                      setLines(
                        lines.map((x) => (x.product.id === l.product.id ? { ...x, unitCost: Number(e.target.value) } : x)),
                      )
                    }
                    className="num h-10 w-28 text-right"
                  />
                  <button onClick={() => setLines(lines.filter((x) => x.product.id !== l.product.id))} aria-label="remove">
                    <Trash2 className="size-4 text-destructive" />
                  </button>
                </li>
              ))}
            </ul>

            <div className="space-y-1.5">
              <Label>{t("notes")}</Label>
              <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} />
            </div>

            <div className="rounded-lg bg-secondary p-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">{t("goodsCost")}</span>
                <span className="num font-semibold">{money(goodsCost, currency)}</span>
              </div>
              <div className="mt-1 flex justify-between">
                <span className="text-muted-foreground">{t("totalCost")}</span>
                <span className="num text-lg font-extrabold">{money(totalCost, currency)}</span>
              </div>
            </div>

            <DialogFooter>
              <Button variant="secondary" onClick={() => setOpen(false)}>
                {t("cancel")}
              </Button>
              <Button onClick={() => save.mutate()} disabled={save.isPending}>
                {t("save")}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <div className="space-y-3">
          {purchases.map((p) => {
            const row = p as unknown as {
              id: string;
              supplier_name: string | null;
              purchase_date: string;
              total_cost: number;
              other_costs: number;
              created_by_name: string | null;
              purchase_items: { id: string; product_name: string; quantity: number; total: number }[];
            };
            return (
              <div key={row.id} className="stat-card">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-bold">{row.supplier_name || t("supplier")}</p>
                    <p className="text-xs text-muted-foreground">
                      {dateOnly(row.purchase_date)} · {row.created_by_name}
                    </p>
                  </div>
                  <div className="flex items-center gap-1">
                    <p className="num text-lg font-extrabold">{money(row.total_cost, currency)}</p>
                    {isAdmin && (
                      <DeleteButton
                        title={t("deletePurchase")}
                        description={t("deletePurchaseConfirm")}
                        pending={delPurchase.isPending}
                        onConfirm={() => delPurchase.mutate(row.id)}
                      />
                    )}
                  </div>
                </div>
                <ul className="mt-2 divide-y divide-border text-sm">
                  {row.purchase_items?.map((i) => (
                    <li key={i.id} className="flex justify-between py-1.5">
                      <span>
                        {i.product_name} <span className="num text-muted-foreground">×{i.quantity}</span>
                      </span>
                      <span className="num">{money(i.total, currency)}</span>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
          {purchases.length === 0 && (
            <div className="stat-card text-center text-sm text-muted-foreground">{t("noData")}</div>
          )}
        </div>
      </div>
    </Guard>
  );
}
