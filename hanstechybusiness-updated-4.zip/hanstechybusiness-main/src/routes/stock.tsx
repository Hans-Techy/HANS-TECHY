import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Search, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Guard } from "@/components/Guard";
import { CategoryManager } from "@/components/CategoryManager";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import {
  fetchCategories,
  fetchProducts,
  fetchSettings,
  fetchSuppliers,
  qk,
  type Product,
} from "@/lib/data";
import { money } from "@/lib/format";
import { useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/stock")({
  head: () => ({
    meta: [
      { title: "Stoo — SHOP" },
      {
        name: "description",
        content: "Simamia bidhaa zako: bei, idadi, gharama, faida kwa kipande na tahadhari ya kuisha.",
      },
      { property: "og:title", content: "Stoo — SHOP" },
      { property: "og:description", content: "Manage products, prices, quantities and low-stock alerts." },
    ],
  }),
  component: StockPage,
});

const EMPTY = {
  name: "",
  sku: "",
  category_id: "",
  supplier_id: "",
  quantity: "0",
  unit: "pcs",
  cost_price: "0",
  wholesale_price: "0",
  selling_price: "0",
  reorder_level: "10",
  item_type: "product",
};

const UNITS = ["pcs", "kg", "g", "ltr", "ml", "mtr", "box", "katoni", "gunia", "pakiti", "ndoo", "tani", "dozen", "jozi", "huduma"];

function StockPage() {
  const { t } = useI18n();
  const { isManager, roles, isAdmin } = useAuth();
  const qc = useQueryClient();
  const canEdit = isManager || roles.includes("storekeeper");

  const { data: settings } = useQuery({ queryKey: qk.settings, queryFn: fetchSettings });
  const { data: products = [] } = useQuery({ queryKey: qk.products, queryFn: fetchProducts });
  const { data: categories = [] } = useQuery({ queryKey: qk.categories, queryFn: fetchCategories });
  const { data: suppliers = [] } = useQuery({ queryKey: qk.suppliers, queryFn: fetchSuppliers });
  const currency = settings?.currency ?? "TZS";

  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [form, setForm] = useState({ ...EMPTY });

  const openNew = () => {
    setEditing(null);
    setForm({ ...EMPTY });
    setOpen(true);
  };

  const openEdit = (p: Product) => {
    setEditing(p);
    setForm({
      name: p.name,
      sku: p.sku ?? "",
      category_id: p.category_id ?? "",
      supplier_id: p.supplier_id ?? "",
      quantity: String(p.quantity),
      unit: p.unit,
      cost_price: String(p.cost_price),
      wholesale_price: String(p.wholesale_price),
      selling_price: String(p.selling_price),
      reorder_level: String(p.reorder_level),
      item_type: p.item_type ?? "product",
    });
    setOpen(true);
  };

  const save = useMutation({
    mutationFn: async () => {
      const payload = {
        name: form.name.trim(),
        sku: form.sku.trim() || null,
        category_id: form.category_id || null,
        supplier_id: form.supplier_id || null,
        quantity: Number(form.quantity) || 0,
        unit: form.unit || "pcs",
        cost_price: Number(form.cost_price) || 0,
        wholesale_price: Number(form.wholesale_price) || 0,
        selling_price: Number(form.selling_price) || 0,
        reorder_level: Number(form.reorder_level) || 0,
        item_type: form.item_type,
      };
      if (!payload.name) throw new Error(t("name"));
      if (editing) {
        const { error } = await supabase.from("products").update(payload).eq("id", editing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("products").insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast.success(t("saved"));
      setOpen(false);
      void qc.invalidateQueries({ queryKey: qk.products });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : t("error")),
  });

  const [newCat, setNewCat] = useState("");
  const addCategory = useMutation({
    mutationFn: async () => {
      const name = newCat.trim();
      if (!name) throw new Error(t("category"));
      const existing = categories.find((c) => c.name.toLowerCase() === name.toLowerCase());
      if (existing) return existing.id;
      const { data, error } = await supabase.from("categories").insert({ name }).select("id").single();
      if (error) throw error;
      return data.id as string;
    },
    onSuccess: (id) => {
      setForm((f) => ({ ...f, category_id: id }));
      setNewCat("");
      toast.success(t("saved"));
      void qc.invalidateQueries({ queryKey: qk.categories });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : t("error")),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("products").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success(t("saved"));
      void qc.invalidateQueries({ queryKey: qk.products });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : t("error")),
  });

  const rows = products.filter((p) => {
    const needle = q.trim().toLowerCase();
    if (!needle) return true;
    return p.name.toLowerCase().includes(needle) || (p.sku ?? "").toLowerCase().includes(needle);
  });

  const stockValue = products.filter((p) => p.item_type !== "service").reduce((a, p) => a + Number(p.quantity) * Number(p.cost_price), 0);

  return (
    <Guard area="stock" title={t("stock")}>
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative min-w-[200px] flex-1">
            <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("search")} className="h-11 pl-9" />
          </div>
          {isManager && <CategoryManager />}
          {canEdit && (
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button className="h-11 font-bold" onClick={openNew}>
                  + {t("newProduct")}
                </Button>
              </DialogTrigger>
              <DialogContent className="max-h-[85vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>{editing ? t("edit") : t("newProduct")}</DialogTitle>
                </DialogHeader>
                <div className="grid gap-3 sm:grid-cols-2">
                  <Field label={t("name")} value={form.name} onChange={(v) => setForm({ ...form, name: v })} />
                  <Field label={t("sku")} value={form.sku} onChange={(v) => setForm({ ...form, sku: v })} />
                  <div className="space-y-1.5">
                    <Label>{t("category")}</Label>
                    <Select value={form.category_id} onValueChange={(v) => setForm({ ...form, category_id: v })}>
                      <SelectTrigger className="h-11">
                        <SelectValue placeholder="—" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((c) => (
                          <SelectItem key={c.id} value={c.id}>
                            {c.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <div className="flex gap-2">
                      <Input
                        value={newCat}
                        onChange={(e) => setNewCat(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            addCategory.mutate();
                          }
                        }}
                        placeholder={t("newCategory")}
                        className="h-10"
                      />
                      <Button type="button" variant="secondary" className="h-10" onClick={() => addCategory.mutate()} disabled={addCategory.isPending || !newCat.trim()}>
                        +
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label>{t("itemType")}</Label>
                    <Select value={form.item_type} onValueChange={(v) => setForm({ ...form, item_type: v, unit: v === "service" ? "huduma" : form.unit })}>
                      <SelectTrigger className="h-11">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="product">{t("physicalProduct")}</SelectItem>
                        <SelectItem value="service">{t("service")}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>{t("supplier")}</Label>
                    <Select value={form.supplier_id} onValueChange={(v) => setForm({ ...form, supplier_id: v })}>
                      <SelectTrigger className="h-11">
                        <SelectValue placeholder="—" />
                      </SelectTrigger>
                      <SelectContent>
                        {suppliers.map((s) => (
                          <SelectItem key={s.id} value={s.id}>
                            {s.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {form.item_type !== "service" && (
                    <Field label={t("quantity")} type="number" value={form.quantity} onChange={(v) => setForm({ ...form, quantity: v })} />
                  )}
                  <div className="space-y-1.5">
                    <Label>{t("unit")}</Label>
                    <Input list="unit-options" value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} className="h-11" />
                    <datalist id="unit-options">
                      {UNITS.map((u) => (
                        <option key={u} value={u} />
                      ))}
                    </datalist>
                  </div>
                  <Field label={t("costPrice")} type="number" value={form.cost_price} onChange={(v) => setForm({ ...form, cost_price: v })} />
                  <Field label={t("wholesalePrice")} type="number" value={form.wholesale_price} onChange={(v) => setForm({ ...form, wholesale_price: v })} />
                  <Field label={t("sellingPrice")} type="number" value={form.selling_price} onChange={(v) => setForm({ ...form, selling_price: v })} />
                  <Field label={t("reorderLevel")} type="number" value={form.reorder_level} onChange={(v) => setForm({ ...form, reorder_level: v })} />
                </div>
                <div className="rounded-lg bg-secondary p-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{t("totalCost")}</span>
                    <span className="num font-bold">
                      {money(Number(form.quantity) * Number(form.cost_price), currency)}
                    </span>
                  </div>
                  <div className="mt-1 flex justify-between">
                    <span className="text-muted-foreground">{t("profitPerPiece")}</span>
                    <span className="num font-bold text-profit">
                      {money(Number(form.selling_price) - Number(form.cost_price), currency)}
                    </span>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="secondary" onClick={() => setOpen(false)}>
                    {t("cancel")}
                  </Button>
                  <Button onClick={() => save.mutate()} disabled={save.isPending}>
                    {t("save")}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </div>

        <div className="stat-card flex items-center justify-between">
          <span className="text-sm font-semibold text-muted-foreground">{t("stockValue")}</span>
          <span className="num text-xl font-extrabold">{money(stockValue, currency)}</span>
        </div>

        <div className="stat-card overflow-x-auto p-0">
          <table className="w-full min-w-[640px] text-sm">
            <thead className="border-b border-border text-left text-xs uppercase text-muted-foreground">
              <tr>
                <th className="p-3">{t("product")}</th>
                <th className="p-3 text-right">{t("quantity")}</th>
                <th className="p-3 text-right">{t("costPrice")}</th>
                <th className="p-3 text-right">{t("sellingPrice")}</th>
                <th className="p-3 text-right">{t("profitPerPiece")}</th>
                <th className="p-3" />
              </tr>
            </thead>
            <tbody>
              {rows.map((p) => {
                const isService = p.item_type === "service";
                const low = !isService && Number(p.quantity) <= Number(p.reorder_level);
                return (
                  <tr key={p.id} className="border-b border-border last:border-0">
                    <td className="p-3">
                      <p className="font-semibold">{p.name}</p>
                      <p className="text-xs text-muted-foreground">{p.sku}</p>
                    </td>
                    <td className={`num p-3 text-right font-bold ${low ? "text-debt" : ""}`}>
                      {isService ? t("service") : `${Number(p.quantity)} ${p.unit}`}
                    </td>
                    <td className="num p-3 text-right">{money(p.cost_price, currency)}</td>
                    <td className="num p-3 text-right">{money(p.selling_price, currency)}</td>
                    <td className="num p-3 text-right text-profit">
                      {money(Number(p.selling_price) - Number(p.cost_price), currency)}
                    </td>
                    <td className="p-3 text-right">
                      {canEdit && (
                        <Button variant="ghost" size="sm" onClick={() => openEdit(p)}>
                          {t("edit")}
                        </Button>
                      )}
                      {isAdmin && (
                        <Button variant="ghost" size="icon" onClick={() => remove.mutate(p.id)} aria-label="delete">
                          <Trash2 className="size-4 text-destructive" />
                        </Button>
                      )}
                    </td>
                  </tr>
                );
              })}
              {rows.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-6 text-center text-muted-foreground">
                    {t("noData")}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </Guard>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
}) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      <Input type={type} step={type === "number" ? "any" : undefined} value={value} onChange={(e) => onChange(e.target.value)} className="h-11" />
    </div>
  );
}
