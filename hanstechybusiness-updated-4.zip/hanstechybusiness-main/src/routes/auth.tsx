import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, CheckCircle2, Eye, EyeOff, Loader2, Mail } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { BrandMark } from "@/components/BrandMark";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Ingia — SHOP" },
      { name: "description", content: "Ingia kwenye mfumo wa kusimamia biashara yako." },
      { property: "og:title", content: "Ingia — SHOP" },
      { property: "og:description", content: "Sign in to your business management system." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

type Mode = "signin" | "signup" | "forgot" | "link";

function AuthPage() {
  const { t, lang, setLang } = useI18n();
  const L = (sw: string, en: string) => (lang === "sw" ? sw : en);
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [businessName, setBusinessName] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState<string | null>(null);

  useEffect(() => {
    if (!loading && user) void navigate({ to: "/" });
  }, [loading, user, navigate]);

  const go = (m: Mode) => {
    setSent(null);
    setMode(m);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "forgot") {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        setSent(t("resetSent"));
      } else if (mode === "link") {
        // Passwordless: Supabase emails a one-tap sign-in link.
        const { error } = await supabase.auth.signInWithOtp({
          email,
          options: { emailRedirectTo: window.location.origin, shouldCreateUser: false },
        });
        if (error) throw error;
        setSent(L("Tumetuma link ya kuingia kwenye email yako. Ifungue kuingia moja kwa moja.", "We sent a sign-in link to your email. Open it to sign in instantly."));
      } else if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin, data: { full_name: fullName, business_name: businessName } },
        });
        if (error) throw error;
        setSent(L("Akaunti imetengenezwa. Angalia email yako kuthibitisha, kisha ingia.", "Account created. Check your email to confirm, then sign in."));
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        void navigate({ to: "/" });
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("error"));
    } finally {
      setBusy(false);
    }
  };

  const google = async () => {
    const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (result.error) {
      toast.error(t("error"));
      return;
    }
    if (result.redirected) return;
    void navigate({ to: "/" });
  };

  const title =
    mode === "forgot" ? t("forgotPassword") : mode === "link" ? L("Ingia kwa email", "Sign in with email link") : mode === "signup" ? t("signUp") : t("signIn");
  const cta =
    mode === "forgot" ? t("sendResetLink") : mode === "link" ? L("Tuma link ya kuingia", "Send sign-in link") : mode === "signup" ? t("signUp") : t("signIn");
  const tabbed = mode === "signin" || mode === "signup";

  return (
    <div className="relative grid min-h-screen place-items-center overflow-hidden bg-background px-4 py-10">
      <div aria-hidden className="anim-drift pointer-events-none absolute -left-24 -top-24 size-80 rounded-full bg-primary/20 blur-3xl" />
      <div aria-hidden className="anim-drift-slow pointer-events-none absolute -bottom-28 -right-20 size-96 rounded-full bg-accent blur-3xl" />

      <div className="relative w-full max-w-sm">
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BrandMark name={mode === "signup" ? businessName : undefined} size={48} />
            <div className="anim-rise leading-tight" style={{ animationDelay: "120ms" }}>
              <p className="text-lg font-extrabold tracking-tight">{t("appName")}</p>
              <p className="text-xs text-muted-foreground">{L("Mauzo, stoo na madeni sehemu moja", "Sales, stock and debts in one place")}</p>
            </div>
          </div>
          <Button variant="secondary" size="sm" onClick={() => setLang(lang === "sw" ? "en" : "sw")}>
            {lang === "sw" ? "SW" : "EN"}
          </Button>
        </div>

        <div className="anim-rise rounded-2xl border border-border bg-card/90 p-5 shadow-[var(--shadow-card)] backdrop-blur" style={{ animationDelay: "180ms" }}>
          {tabbed ? (
            <div className="relative mb-5 grid grid-cols-2 rounded-xl bg-secondary p-1 text-sm font-semibold">
              <span
                aria-hidden
                className="absolute inset-y-1 left-1 w-[calc(50%-0.25rem)] rounded-lg bg-card shadow-sm transition-transform duration-300 ease-out"
                style={{ transform: mode === "signup" ? "translateX(100%)" : "none" }}
              />
              <button type="button" onClick={() => go("signin")} className={`relative z-10 py-2 transition-colors ${mode === "signin" ? "text-foreground" : "text-muted-foreground"}`}>{t("signIn")}</button>
              <button type="button" onClick={() => go("signup")} className={`relative z-10 py-2 transition-colors ${mode === "signup" ? "text-foreground" : "text-muted-foreground"}`}>{t("signUp")}</button>
            </div>
          ) : (
            <button type="button" onClick={() => go("signin")} className="mb-4 inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:underline">
              <ArrowLeft className="size-4" /> {t("backToSignIn")}
            </button>
          )}

          <div key={`${mode}-${sent ? "sent" : "form"}`} className="anim-swap">
            {sent ? (
              <div className="py-6 text-center">
                <CheckCircle2 className="anim-pop mx-auto size-12 text-profit" />
                <p className="mt-3 text-sm text-muted-foreground">{sent}</p>
                <Button variant="secondary" className="mt-5" onClick={() => go("signin")}>{t("backToSignIn")}</Button>
              </div>
            ) : (
              <>
                <h2 className="text-xl font-bold tracking-tight">{title}</h2>
                <form onSubmit={submit} className="mt-4 space-y-3">
                  {mode === "signup" && (
                    <>
                      <div className="space-y-1.5">
                        <Label htmlFor="businessName">{t("businessName")}</Label>
                        <Input id="businessName" value={businessName} onChange={(e) => setBusinessName(e.target.value)} required className="h-12" />
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="fullName">{t("fullName")}</Label>
                        <Input id="fullName" value={fullName} onChange={(e) => setFullName(e.target.value)} required className="h-12" />
                      </div>
                    </>
                  )}
                  <div className="space-y-1.5">
                    <Label htmlFor="email">{t("email")}</Label>
                    <Input id="email" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="h-12" />
                  </div>
                  {(mode === "signin" || mode === "signup") && (
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="password">{t("password")}</Label>
                        {mode === "signin" && (
                          <button type="button" className="text-xs font-semibold text-primary hover:underline" onClick={() => go("forgot")}>
                            {t("forgotPassword")}
                          </button>
                        )}
                      </div>
                      <div className="relative">
                        <Input
                          id="password"
                          type={showPw ? "text" : "password"}
                          autoComplete={mode === "signin" ? "current-password" : "new-password"}
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          required
                          minLength={6}
                          className="h-12 pr-11"
                        />
                        <button type="button" aria-label={showPw ? L("Ficha nenosiri", "Hide password") : L("Onyesha nenosiri", "Show password")} onClick={() => setShowPw((v) => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                          {showPw ? <EyeOff className="size-5" /> : <Eye className="size-5" />}
                        </button>
                      </div>
                    </div>
                  )}
                  <Button type="submit" disabled={busy} className="h-12 w-full text-base font-bold transition-transform active:scale-[0.98]">
                    {busy && <Loader2 className="mr-2 size-4 animate-spin" />}
                    {cta}
                  </Button>
                </form>

                {mode === "signin" && (
                  <Button type="button" variant="ghost" onClick={() => go("link")} className="mt-2 h-11 w-full font-semibold">
                    <Mail className="mr-2 size-4" /> {L("Ingia kwa link ya email", "Email me a sign-in link")}
                  </Button>
                )}

                {tabbed && (
                  <>
                    <div className="my-4 flex items-center gap-3 text-xs text-muted-foreground">
                      <span className="h-px flex-1 bg-border" />
                      {L("au", "or")}
                      <span className="h-px flex-1 bg-border" />
                    </div>
                    <Button variant="outline" onClick={google} className="h-12 w-full font-semibold transition-transform active:scale-[0.98]">
                      {t("continueGoogle")}
                    </Button>
                  </>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
