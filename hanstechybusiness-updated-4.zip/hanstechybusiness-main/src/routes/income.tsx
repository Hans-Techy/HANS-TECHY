import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Guard } from "@/components/Guard";
import { StatCard } from "@/components/StatCard";
import { Button } from "@/components/ui/button";
import { fetchExpenses, fetchPayments, fetchSales, fetchSettings, qk } from "@/lib/data";
import { dateTime, money, rangeBounds, type RangeKey } from "@/lib/format";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/income")({
  head: () => ({
    meta: [
      { title: "Mapato — SHOP" },
      {
        name: "description",
        content: "Mapato, gharama ya bidhaa, matumizi, faida ghafi na faida halisi ya biashara.",
      },
      { property: "og:title", content: "Mapato — SHOP" },
      { property: "og:description", content: "Revenue, cost of goods, expenses, gross and net profit." },
    ],
  }),
  component: IncomePage,
});

const KEYS: RangeKey[] = ["today", "week", "month", "year"];

function IncomePage() {
  const { t } = useI18n();
  const [range, setRange] = useState<RangeKey>("month");

  const { data: settings } = useQuery({ queryKey: qk.settings, queryFn: fetchSettings });
  const { data: sales = [] } = useQuery({ queryKey: qk.sales, queryFn: fetchSales });
  const { data: expenses = [] } = useQuery({ queryKey: qk.expenses, queryFn: fetchExpenses });
  const { data: payments = [] } = useQuery({ queryKey: qk.payments, queryFn: fetchPayments });
  const currency = settings?.currency ?? "TZS";

  const { start, end } = rangeBounds(range);
  const inRange = sales.filter((s) => {
    const d = new Date(s.created_at);
    return d >= start && d <= end;
  });
  const expInRange = (expenses as unknown as { amount: number; expense_date: string }[]).filter((e) => {
    const d = new Date(`${e.expense_date}T12:00:00`);
    return d >= start && d <= end;
  });

  const revenue = inRange.reduce((a, s) => a + Number(s.total), 0);
  const cogs = inRange.reduce((a, s) => a + Number(s.cost_total), 0);
  const gross = revenue - cogs;
  const expenseTotal = expInRange.reduce((a, e) => a + Number(e.amount), 0);
  const net = gross - expenseTotal;
  const cashIn =
    inRange.reduce((a, s) => a + Number(s.paid), 0) +
    (payments as unknown as { amount: number; created_at: string }[])
      .filter((p) => {
        const d = new Date(p.created_at);
        return d >= start && d <= end;
      })
      .reduce((a, p) => a + Number(p.amount), 0);

  return (
    <Guard area="income" title={t("income")}>
      <div className="space-y-4">
        <div className="flex flex-wrap gap-2">
          {KEYS.map((k) => (
            <Button
              key={k}
              variant={range === k ? "default" : "secondary"}
              className="h-10 font-semibold"
              onClick={() => setRange(k)}
            >
              {t(k)}
            </Button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-3 lg:grid-cols-3">
          <StatCard label={t("revenue")} value={money(revenue, currency)} />
          <StatCard label={t("cogs")} value={money(cogs, currency)} />
          <StatCard label={t("grossProfit")} value={money(gross, currency)} tone="profit" />
          <StatCard label={t("expenses")} value={money(expenseTotal, currency)} tone="debt" />
          <StatCard label={t("netProfit")} value={money(net, currency)} tone={net >= 0 ? "profit" : "debt"} />
          <StatCard label={t("totalPaid")} value={money(cashIn, currency)} />
        </div>

        <div className="stat-card p-0">
          <p className="border-b border-border p-3 text-sm font-bold">{t("transactions")}</p>
          <ul className="divide-y divide-border">
            {inRange.slice(0, 50).map((s) => (
              <li key={s.id} className="flex items-center justify-between gap-3 p-3 text-sm">
                <div className="min-w-0">
                  <p className="num font-semibold">{s.receipt_no}</p>
                  <p className="truncate text-xs text-muted-foreground">{dateTime(s.created_at)}</p>
                </div>
                <div className="text-right">
                  <p className="num font-bold">{money(s.total, currency)}</p>
                  <p className="num text-xs text-profit">+{money(s.profit, currency)}</p>
                </div>
              </li>
            ))}
            {inRange.length === 0 && (
              <li className="p-6 text-center text-sm text-muted-foreground">{t("noData")}</li>
            )}
          </ul>
        </div>
      </div>
    </Guard>
  );
}
