import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

type Ctx = { supabase: any; userId: string };

async function requireOwner(context: Ctx) {
  const [{ data: isAdmin }, { data: biz }] = await Promise.all([
    context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" }),
    context.supabase.rpc("my_business"),
  ]);
  if (!isAdmin || !biz) throw new Error("Only the business owner/admin can manage staff");
  return biz as string;
}

export const createStaff = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z
      .object({
        fullName: z.string().trim().min(1).max(100),
        email: z.string().trim().email().max(255),
        password: z.string().min(6).max(72),
        role: z.enum(["admin", "manager", "salesperson", "storekeeper"]),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const businessId = await requireOwner(context as Ctx);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
      email: data.email,
      password: data.password,
      email_confirm: true,
      user_metadata: { full_name: data.fullName },
      app_metadata: { business_id: businessId, role: data.role },
    });
    if (error) throw new Error(error.message);
    if (created.user) {
      const { error: syncErr } = await supabaseAdmin.rpc("sync_staff_business", { p_user_id: created.user.id });
      if (syncErr) throw new Error(syncErr.message);
    }
    return { ok: true };
  });

export const deleteStaff = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ userId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const businessId = await requireOwner(context as Ctx);
    if (data.userId === (context as Ctx).userId) throw new Error("You cannot delete your own account");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: target } = await supabaseAdmin
      .from("profiles")
      .select("business_id")
      .eq("id", data.userId)
      .maybeSingle();
    if (!target || target.business_id !== businessId) throw new Error("User not found in your business");
    const { error } = await supabaseAdmin.auth.admin.deleteUser(data.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
