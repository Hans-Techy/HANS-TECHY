import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export type Role = "admin" | "manager" | "salesperson" | "storekeeper";

type AuthCtx = {
  user: User | null;
  session: Session | null;
  roles: Role[];
  fullName: string;
  loading: boolean;
  isManager: boolean;
  isAdmin: boolean;
  can: (area: Area) => boolean;
  refresh: () => Promise<void>;
};

export type Area =
  | "dashboard"
  | "sales"
  | "purchases"
  | "stock"
  | "customers"
  | "income"
  | "expenses"
  | "reports"
  | "users"
  | "settings";

const Ctx = createContext<AuthCtx>({
  user: null,
  session: null,
  roles: [],
  fullName: "",
  loading: true,
  isManager: false,
  isAdmin: false,
  can: () => false,
  refresh: async () => {},
});

const ACCESS: Record<Area, Role[]> = {
  dashboard: ["admin", "manager", "salesperson", "storekeeper"],
  sales: ["admin", "manager", "salesperson"],
  purchases: ["admin", "manager", "storekeeper"],
  stock: ["admin", "manager", "salesperson", "storekeeper"],
  customers: ["admin", "manager", "salesperson"],
  income: ["admin", "manager"],
  expenses: ["admin", "manager"],
  reports: ["admin", "manager"],
  users: ["admin"],
  settings: ["admin", "manager", "salesperson", "storekeeper"],
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [roles, setRoles] = useState<Role[]>([]);
  const [fullName, setFullName] = useState("");
  const [loading, setLoading] = useState(true);

  const loadProfile = async (userId: string) => {
    const [{ data: roleRows }, { data: profile }] = await Promise.all([
      supabase.from("user_roles").select("role").eq("user_id", userId),
      supabase.from("profiles").select("full_name, active").eq("id", userId).maybeSingle(),
    ]);
    // Deactivated users keep their login but lose access to every area
    setRoles(profile?.active === false ? [] : ((roleRows ?? []) as { role: Role }[]).map((r) => r.role));
    setFullName(profile?.full_name ?? "");
  };

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => {
      setSession(s);
      if (s?.user) {
        setTimeout(() => void loadProfile(s.user.id), 0);
      } else {
        setRoles([]);
        setFullName("");
      }
      setLoading(false);
    });

    void supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      if (data.session?.user) void loadProfile(data.session.user.id);
      setLoading(false);
    });

    return () => sub.subscription.unsubscribe();
  }, []);

  const isAdmin = roles.includes("admin");
  const isManager = isAdmin || roles.includes("manager");

  const value: AuthCtx = {
    user: session?.user ?? null,
    session,
    roles,
    fullName,
    loading,
    isManager,
    isAdmin,
    can: (area) => roles.some((r) => ACCESS[area].includes(r)),
    refresh: async () => {
      if (session?.user) await loadProfile(session.user.id);
    },
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  return useContext(Ctx);
}
