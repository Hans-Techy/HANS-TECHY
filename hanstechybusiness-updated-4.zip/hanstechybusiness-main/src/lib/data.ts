import { supabase } from "@/integrations/supabase/client";

export type Product = {
  id: string;
  name: string;
  sku: string | null;
  category_id: string | null;
  supplier_id: string | null;
  quantity: number;
  unit: string;
  cost_price: number;
  wholesale_price: number;
  selling_price: number;
  reorder_level: number;
  active: boolean;
  item_type?: string;
};

export type Customer = {
  id: string;
  name: string;
  phone: string | null;
  address: string | null;
  created_at: string;
};

export type Sale = {
  id: string;
  receipt_no: string;
  customer_id: string | null;
  customer_name: string | null;
  customer_phone: string | null;
  subtotal: number;
  discount: number;
  total: number;
  paid: number;
  balance: number;
  cost_total: number;
  profit: number;
  payment_method: "cash" | "mobile_money" | "bank" | "other";
  sold_by_name: string | null;
  created_at: string;
};

export type SaleItem = {
  id: string;
  sale_id: string;
  product_id: string | null;
  product_name: string;
  quantity: number;
  unit_price: number;
  unit_cost: number;
  total: number;
};

export const qk = {
  settings: ["business"] as const,
  products: ["products"] as const,
  categories: ["categories"] as const,
  suppliers: ["suppliers"] as const,
  customers: ["customers"] as const,
  sales: ["sales"] as const,
  purchases: ["purchases"] as const,
  payments: ["payments"] as const,
  expenses: ["expenses"] as const,
  profiles: ["profiles"] as const,
  roles: ["user_roles"] as const,
};

export async function fetchSettings() {
  const { data, error } = await supabase.from("businesses").select("*").limit(1).maybeSingle();
  if (error) throw error;
  return data;
}

export async function fetchProducts() {
  const { data, error } = await supabase.from("products").select("*").order("name");
  if (error) throw error;
  return (data ?? []) as unknown as Product[];
}

export async function fetchCategories() {
  const { data, error } = await supabase.from("categories").select("*").order("name");
  if (error) throw error;
  return data ?? [];
}

export async function fetchSuppliers() {
  const { data, error } = await supabase.from("suppliers").select("*").order("name");
  if (error) throw error;
  return data ?? [];
}

export async function fetchCustomers() {
  const { data, error } = await supabase.from("customers").select("*").order("name");
  if (error) throw error;
  return (data ?? []) as unknown as Customer[];
}

export async function fetchSales() {
  const { data, error } = await supabase
    .from("sales")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(2000);
  if (error) throw error;
  return (data ?? []) as unknown as Sale[];
}

export async function fetchSaleWithItems(id: string) {
  const [{ data: sale, error: e1 }, { data: items, error: e2 }] = await Promise.all([
    supabase.from("sales").select("*").eq("id", id).maybeSingle(),
    supabase.from("sale_items").select("*").eq("sale_id", id),
  ]);
  if (e1) throw e1;
  if (e2) throw e2;
  return { sale: sale as unknown as Sale | null, items: (items ?? []) as unknown as SaleItem[] };
}

export async function fetchPurchases() {
  const { data, error } = await supabase
    .from("purchases")
    .select("*, purchase_items(*)")
    .order("created_at", { ascending: false })
    .limit(500);
  if (error) throw error;
  return data ?? [];
}

export async function fetchPayments() {
  const { data, error } = await supabase
    .from("payments")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(1000);
  if (error) throw error;
  return data ?? [];
}

export async function fetchExpenses() {
  const { data, error } = await supabase
    .from("expenses")
    .select("*")
    .order("expense_date", { ascending: false })
    .limit(1000);
  if (error) throw error;
  return data ?? [];
}

export function downloadCsv(filename: string, rows: (string | number)[][]) {
  const csv = rows
    .map((r) =>
      r
        .map((c) => {
          let v = String(c ?? "");
          if (typeof c === "string" && /^[=+\-@\t\r]/.test(v)) v = "'" + v;
          return `"${v.replace(/"/g, '""')}"`;
        })
        .join(","),
    )
    .join("\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
