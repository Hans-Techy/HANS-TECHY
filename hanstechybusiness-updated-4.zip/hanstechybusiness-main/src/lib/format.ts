export function money(value: number | null | undefined, currency = "TZS") {
  const n = Number(value ?? 0);
  return `${currency} ${n.toLocaleString("en-US", { maximumFractionDigits: 0 })}`;
}

export function num(value: number | null | undefined) {
  return Number(value ?? 0).toLocaleString("en-US", { maximumFractionDigits: 2 });
}

export function dateTime(value: string | Date) {
  const d = typeof value === "string" ? new Date(value) : value;
  return d.toLocaleString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function dateOnly(value: string | Date) {
  const d = typeof value === "string" ? new Date(value) : value;
  return d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
}

export type RangeKey = "today" | "week" | "month" | "year" | "custom";

export function rangeBounds(key: RangeKey, from?: string, to?: string) {
  const now = new Date();
  const start = new Date(now);
  const end = new Date(now);
  end.setHours(23, 59, 59, 999);

  if (key === "today") {
    start.setHours(0, 0, 0, 0);
  } else if (key === "week") {
    const day = (start.getDay() + 6) % 7;
    start.setDate(start.getDate() - day);
    start.setHours(0, 0, 0, 0);
  } else if (key === "month") {
    start.setDate(1);
    start.setHours(0, 0, 0, 0);
  } else if (key === "year") {
    start.setMonth(0, 1);
    start.setHours(0, 0, 0, 0);
  } else {
    return {
      start: from ? new Date(`${from}T00:00:00`) : start,
      end: to ? new Date(`${to}T23:59:59`) : end,
    };
  }
  return { start, end };
}
