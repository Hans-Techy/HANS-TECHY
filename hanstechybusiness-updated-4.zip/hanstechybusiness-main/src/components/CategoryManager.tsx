import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Tags } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { DeleteButton } from "@/components/DeleteButton";
import { supabase } from "@/integrations/supabase/client";
import { fetchCategories, qk } from "@/lib/data";
import { useI18n } from "@/lib/i18n";

export function CategoryManager() {
  const { t, lang } = useI18n();
  const sw = lang === "sw";
  const qc = useQueryClient();
  const { data: categories = [] } = useQuery({ queryKey: qk.categories, queryFn: fetchCategories });
  const [name, setName] = useState("");
  const refresh = () => {
    void qc.invalidateQueries({ queryKey: qk.categories });
    void qc.invalidateQueries({ queryKey: qk.products });
  };
  const onErr = (e: unknown) => toast.error(e instanceof Error ? e.message : t("error"));

  const add = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("categories").insert({ name: name.trim() });
      if (error) throw error;
    },
    onSuccess: () => { setName(""); toast.success(t("saved")); refresh(); },
    onError: onErr,
  });
  const rename = useMutation({
    mutationFn: async ({ id, n }: { id: string; n: string }) => {
      const { error } = await supabase.from("categories").update({ name: n }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { toast.success(t("saved")); refresh(); },
    onError: onErr,
  });
  const del = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.rpc("delete_category", { p_category_id: id });
      if (error) throw error;
    },
    onSuccess: () => { toast.success(t("deleted")); refresh(); },
    onError: onErr,
  });

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="secondary" className="h-11 font-semibold">
          <Tags className="size-4" /> {sw ? "Makundi" : "Categories"}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{sw ? "Simamia makundi" : "Manage categories"}</DialogTitle>
        </DialogHeader>
        <div className="flex gap-2">
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder={t("newCategory")}
            onKeyDown={(e) => e.key === "Enter" && name.trim() && add.mutate()} />
          <Button disabled={!name.trim() || add.isPending} onClick={() => add.mutate()}>+</Button>
        </div>
        <ul className="divide-y divide-border">
          {categories.map((c) => (
            <li key={c.id} className="flex items-center gap-2 py-2">
              <Input defaultValue={c.name} className="h-9"
                onBlur={(e) => { const n = e.target.value.trim(); if (n && n !== c.name) rename.mutate({ id: c.id, n }); }} />
              <DeleteButton
                title={sw ? "Futa kundi" : "Delete category"}
                description={sw ? "Bidhaa za kundi hili zitabaki bila kundi." : "Products in this category will become uncategorised."}
                onConfirm={() => del.mutate(c.id)}
              />
            </li>
          ))}
          {categories.length === 0 && <li className="py-4 text-center text-sm text-muted-foreground">{t("noData")}</li>}
        </ul>
      </DialogContent>
    </Dialog>
  );
}
