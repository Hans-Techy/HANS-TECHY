import { useEffect, useState } from "react";
import { Download } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n";

type BIPEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> };

export function InstallAppButton() {
  const { lang } = useI18n();
  const sw = lang === "sw";
  const [evt, setEvt] = useState<BIPEvent | null>(null);
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    const standalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (navigator as Navigator & { standalone?: boolean }).standalone === true;
    setInstalled(standalone);
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setEvt(e as BIPEvent);
    };
    const onInstalled = () => setInstalled(true);
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  if (installed) return null;

  const install = async () => {
    if (evt) {
      await evt.prompt();
      await evt.userChoice;
      setEvt(null);
      return;
    }
    const ios = /iphone|ipad|ipod/i.test(navigator.userAgent);
    toast.info(
      ios
        ? sw
          ? "Kwenye Safari: bofya kitufe cha Share, kisha chagua 'Add to Home Screen'."
          : "In Safari: tap Share, then choose 'Add to Home Screen'."
        : sw
          ? "Fungua menyu ya kivinjari (⋮) kisha chagua 'Install app' au 'Add to Home screen'."
          : "Open the browser menu (⋮) and choose 'Install app' or 'Add to Home screen'.",
      { duration: 8000 },
    );
  };

  return (
    <button
      onClick={install}
      className="flex w-full items-center gap-3 rounded-lg px-3 py-3 text-sm font-medium text-primary hover:bg-secondary"
    >
      <Download className="size-5" />
      {sw ? "Sakinisha App" : "Install App"}
    </button>
  );
}
