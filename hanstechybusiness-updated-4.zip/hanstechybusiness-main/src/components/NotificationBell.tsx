import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { Bell, PackageX, AlertTriangle, Wallet, MessageSquare } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { fetchProducts, fetchSales, qk } from "@/lib/data";
import { useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";

export function NotificationBell() {
  const { isManager } = useAuth();
  const { lang } = useI18n();
  const sw = lang === "sw";
  const { data: products = [] } = useQuery({ queryKey: qk.products, queryFn: fetchProducts, enabled: isManager });
  const { data: sales = [] } = useQuery({ queryKey: qk.sales, queryFn: fetchSales, enabled: isManager });
  const { data: fbCount = 0 } = useQuery({
    queryKey: ["feedback", "count"],
    enabled: isManager,
    queryFn: async () => {
      const since = new Date(Date.now() - 7 * 864e5).toISOString();
      const { count } = await supabase.from("feedback").select("id", { count: "exact", head: true }).gte("created_at", since);
      return count ?? 0;
    },
  });
  if (!isManager) return null;

  const stocked = products.filter((p) => p.item_type !== "service");
  const out = stocked.filter((p) => p.quantity <= 0);
  const low = stocked.filter((p) => p.quantity > 0 && p.quantity <= p.reorder_level);
  const debtors = sales.filter((s) => Number(s.balance) > 0);
  const today = new Date().toDateString();
  const todaySales = sales.filter((s) => new Date(s.created_at).toDateString() === today);
  const todayTotal = todaySales.reduce((a, s) => a + Number(s.total), 0);

  const items = [
    out.length > 0 && { icon: PackageX, tone: "text-destructive", to: "/stock", text: sw ? `Bidhaa ${out.length} zimeisha stoo` : `${out.length} products out of stock` },
    low.length > 0 && { icon: AlertTriangle, tone: "text-destructive", to: "/stock", text: sw ? `Bidhaa ${low.length} zinakaribia kuisha` : `${low.length} products low on stock` },
    debtors.length > 0 && { icon: Wallet, tone: "text-destructive", to: "/customers", text: sw ? `Mauzo ${debtors.length} yana madeni` : `${debtors.length} sales with unpaid debt` },
    fbCount > 0 && { icon: MessageSquare, tone: "text-primary", to: "/feedback", text: sw ? `Maoni mapya ${fbCount} (siku 7)` : `${fbCount} new feedback (7 days)` },
  ].filter(Boolean) as { icon: typeof Bell; tone: string; to: string; text: string }[];

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="secondary" size="icon" className="relative size-10" aria-label={sw ? "Taarifa" : "Notifications"}>
          <Bell className="size-5" />
          {items.length > 0 && (
            <span className="absolute -right-1 -top-1 grid size-5 place-items-center rounded-full bg-destructive text-[10px] font-bold text-destructive-foreground">
              {items.length}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 p-0">
        <div className="border-b border-border px-4 py-3">
          <p className="font-bold">{sw ? "Taarifa za Msimamizi" : "Admin notifications"}</p>
          <p className="text-xs text-muted-foreground">
            {sw ? "Mauzo ya leo" : "Today's sales"}: {todaySales.length} · {todayTotal.toLocaleString()}
          </p>
        </div>
        <div className="max-h-80 overflow-y-auto p-2">
          {items.length === 0 ? (
            <p className="px-2 py-6 text-center text-sm text-muted-foreground">{sw ? "Hakuna taarifa mpya" : "No new notifications"}</p>
          ) : (
            items.map((it, i) => (
              <Link key={i} to={it.to} className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm hover:bg-secondary">
                <it.icon className={`size-5 shrink-0 ${it.tone}`} />
                <span>{it.text}</span>
              </Link>
            ))
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}
