import { useEffect, useMemo, useRef, useState } from "react";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import ReactMarkdown from "react-markdown";
import { Bot, RotateCcw, Send, Square, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

// Tailwind's reset strips default markdown styling, so style the elements explicitly.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const el = (Tag: any, cls: string) => ({ node: _n, ...p }: any) => <Tag className={cls} {...p} />;
const MD = {
  p: el("p", "mb-2 leading-relaxed last:mb-0"),
  ul: el("ul", "mb-2 list-disc space-y-1 pl-5"),
  ol: el("ol", "mb-2 list-decimal space-y-1 pl-5"),
  strong: el("strong", "font-semibold"),
  h1: el("h3", "mb-1 mt-2 font-bold"),
  h2: el("h3", "mb-1 mt-2 font-bold"),
  h3: el("h3", "mb-1 mt-2 font-bold"),
  code: el("code", "rounded bg-muted px-1 py-0.5 font-mono text-xs"),
  a: el("a", "text-primary underline"),
};

const SUGGESTIONS = ["Mauzo ya leo ni kiasi gani?", "Bidhaa zipi zinaisha?", "Nani ana deni kubwa?"];

function errorText(message?: string) {
  if (!message) return "";
  try {
    const parsed = JSON.parse(message) as { error?: string };
    if (parsed.error) return parsed.error;
  } catch {
    /* not JSON */
  }
  return message.length < 160 ? message : "Samahani, kuna hitilafu. Jaribu tena.";
}

export function HansTechyAssistant() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const transport = useMemo(
    () =>
      new DefaultChatTransport({
        api: "/api/chat",
        headers: async () => {
          const { data } = await supabase.auth.getSession();
          return {
            Authorization: `Bearer ${data.session?.access_token ?? ""}`,
            "x-tz-offset": String(new Date().getTimezoneOffset()),
          } as Record<string, string>;
        },
      }),
    [],
  );
  const { messages, sendMessage, setMessages, regenerate, status, stop, error } = useChat({ transport });
  const busy = status === "submitted" || status === "streaming";

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, status]);
  useEffect(() => {
    if (open && !busy) inputRef.current?.focus();
  }, [open, busy]);

  const send = (text: string) => {
    const t = text.trim();
    if (!t || busy) return;
    void sendMessage({ text: t });
    setInput("");
  };

  return (
    <>
      {!open && (
        <button
          onClick={() => setOpen(true)}
          aria-label="HANS TECHY msaidizi"
          className="anim-pop fixed bottom-5 right-5 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg transition hover:scale-105 active:scale-95 no-print"
        >
          <Bot className="h-7 w-7" />
        </button>
      )}
      {open && (
        <div className="anim-rise no-print fixed bottom-4 right-4 z-50 flex h-[min(560px,80vh)] w-[min(380px,calc(100vw-2rem))] flex-col overflow-hidden rounded-2xl border bg-card shadow-2xl">
          <div className="flex items-center justify-between bg-primary px-4 py-3 text-primary-foreground">
            <div className="flex items-center gap-2">
              <Bot className="h-5 w-5" />
              <div>
                <div className="text-sm font-bold">HANS TECHY</div>
                <div className="text-xs opacity-80">Msaidizi wa SHOP</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {messages.length > 0 && (
                <button
                  onClick={() => {
                    stop();
                    setMessages([]);
                  }}
                  aria-label="Mazungumzo mapya"
                  title="Mazungumzo mapya"
                >
                  <RotateCcw className="h-4 w-4" />
                </button>
              )}
              <button onClick={() => setOpen(false)} aria-label="Funga">
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>
          <div className="flex-1 space-y-3 overflow-y-auto p-3 text-sm" aria-live="polite">
            {messages.length === 0 && (
              <div className="space-y-3">
                <p className="text-muted-foreground">Habari! Mimi ni HANS TECHY. Naona taarifa za biashara yako moja kwa moja. Niulize:</p>
                <div className="flex flex-col items-start gap-2">
                  {SUGGESTIONS.map((s) => (
                    <button key={s} onClick={() => send(s)} className="rounded-full border border-border bg-secondary px-3 py-1.5 text-left text-xs font-medium transition hover:bg-accent active:scale-[0.98]">
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {messages.map((m) => (
              <div key={m.id} className={m.role === "user" ? "flex justify-end" : "flex"}>
                <div className={m.role === "user" ? "max-w-[85%] rounded-2xl rounded-br-md bg-primary px-3 py-2 text-primary-foreground" : "max-w-[92%] rounded-2xl rounded-bl-md bg-secondary px-3 py-2 text-foreground"}>
                  {m.parts.map((p, i) =>
                    p.type === "text" ? (
                      m.role === "user" ? (
                        <span key={i} className="whitespace-pre-wrap">{p.text}</span>
                      ) : (
                        <ReactMarkdown key={i} components={MD}>{p.text}</ReactMarkdown>
                      )
                    ) : null,
                  )}
                </div>
              </div>
            ))}
            {status === "submitted" && <p className="animate-pulse text-muted-foreground">HANS TECHY anaandika…</p>}
            {error && (
              <div className="space-y-2 rounded-xl border border-destructive/30 bg-destructive/10 p-3 text-destructive">
                <p>{errorText(error.message) || "Samahani, kuna hitilafu. Jaribu tena."}</p>
                <Button size="sm" variant="outline" onClick={() => void regenerate()}>
                  <RotateCcw className="mr-1.5 h-3.5 w-3.5" /> Jaribu tena
                </Button>
              </div>
            )}
            <div ref={endRef} />
          </div>
          <div className="flex items-end gap-2 border-t p-2">
            <textarea
              ref={inputRef}
              rows={1}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send(input);
                }
              }}
              placeholder="Andika swali…"
              className="max-h-28 flex-1 resize-none rounded-lg border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
            />
            {busy ? (
              <Button size="icon" variant="outline" onClick={() => stop()} aria-label="Simamisha"><Square className="h-4 w-4" /></Button>
            ) : (
              <Button size="icon" onClick={() => send(input)} disabled={!input.trim()} aria-label="Tuma"><Send className="h-4 w-4" /></Button>
            )}
          </div>
        </div>
      )}
    </>
  );
}
