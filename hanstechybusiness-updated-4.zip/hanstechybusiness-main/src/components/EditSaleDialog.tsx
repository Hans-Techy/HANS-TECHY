import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { fetchProducts, fetchSaleWithItems, qk, type Sale } from "@/lib/data";
import { money } from "@/lib/format";
import { useI18n } from "@/lib/i18n";

type Line = { product_id: string; name: string; quantity: number; unit_price: number };

export function EditSaleDialog({ sale, currency, onClose }: { sale: Sale | null; currency: string; onClose: () => void }) {
  const { t, lang } = useI18n();
  const sw = lang === "sw";
  const qc = useQueryClient();
  const { data: products = [] } = useQuery({ queryKey: qk.products, queryFn: fetchProducts });
  const { data } = useQuery({
    queryKey: ["sale-edit", sale?.id],
    queryFn: () => fetchSaleWithItems(sale!.id),
    enabled: !!sale,
  });
  const [lines, setLines] = useState<Line[]>([]);
  const [discount, setDiscount] = useState(0);
  const [paid, setPaid] = useState(0);
  const [method, setMethod] = useState("cash");
  const [addId, setAddId] = useState("");

  useEffect(() => {
    if (!data?.sale) return;
    setLines(
      data.items
        .filter((i) => i.product_id)
        .map((i) => ({ product_id: i.product_id!, name: i.product_name, quantity: Number(i.quantity), unit_price: Number(i.unit_price) })),
    );
    setDiscount(Number(data.sale.discount));
    setPaid(Number(data.sale.paid));
    setMethod(String(data.sale.payment_method));
  }, [data]);

  const subtotal = lines.reduce((a, l) => a + l.quantity * l.unit_price, 0);
  const total = Math.max(0, subtotal - discount);
  const balance = Math.max(0, total - Math.min(paid, total));

  const save = useMutation({
    mutationFn: async () => {
      if (!sale) return;
      const { error } = await supabase.rpc("update_sale", {
        p_sale_id: sale.id,
        p_items: lines.map((l) => ({ product_id: l.product_id, quantity: l.quantity, unit_price: l.unit_price })),
        p_discount: discount,
        p_paid: paid,
        p_method: method as "cash",
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success(sw ? "Mauzo yamesahihishwa" : "Sale updated");
      for (const k of [qk.sales, qk.products, qk.customers, qk.payments]) void qc.invalidateQueries({ queryKey: k });
      void qc.invalidateQueries({ queryKey: ["sale"] });
      void qc.invalidateQueries({ queryKey: ["sale-edit"] });
      onClose();
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : t("error")),
  });

  const upd = (i: number, patch: Partial<Line>) => setLines((p) => p.map((l, j) => (j === i ? { ...l, ...patch } : l)));
  const addProduct = (id: string) => {
    const p = products.find((x) => x.id === id);
    if (!p || lines.some((l) => l.product_id === id)) return;
    setLines((prev) => [...prev, { product_id: p.id, name: p.name, quantity: 1, unit_price: Number(p.selling_price) }]);
    setAddId("");
  };

  return (
    <Dialog open={!!sale} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {sw ? "Hariri mauzo" : "Edit sale"} · {sale?.receipt_no}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          {lines.map((l, i) => (
            <div key={l.product_id} className="rounded-lg border border-border p-2">
              <div className="flex items-center justify-between gap-2">
                <p className="truncate text-sm font-semibold">{l.name}</p>
                <Button variant="ghost" size="icon" className="size-8 text-destructive" onClick={() => setLines((p) => p.filter((_, j) => j !== i))}>
                  <Trash2 className="size-4" />
                </Button>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <Label className="text-xs">{sw ? "Idadi" : "Qty"}</Label>
                  <Input type="number" step="any" value={l.quantity} onChange={(e) => upd(i, { quantity: Number(e.target.value) })} />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">{sw ? "Bei" : "Price"}</Label>
                  <Input type="number" value={l.unit_price} onChange={(e) => upd(i, { unit_price: Number(e.target.value) })} />
                </div>
              </div>
            </div>
          ))}
          <Select value={addId} onValueChange={addProduct}>
            <SelectTrigger>
              <SelectValue placeholder={sw ? "+ Ongeza bidhaa" : "+ Add product"} />
            </SelectTrigger>
            <SelectContent>
              {products.filter((p) => !lines.some((l) => l.product_id === p.id)).map((p) => (
                <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <Label className="text-xs">{t("discount")}</Label>
              <Input type="number" value={discount} onChange={(e) => setDiscount(Number(e.target.value))} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">{t("paid")}</Label>
              <Input type="number" value={paid} onChange={(e) => setPaid(Number(e.target.value))} />
            </div>
          </div>
          <Select value={method} onValueChange={setMethod}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="cash">{t("cash")}</SelectItem>
              <SelectItem value="mobile_money">{t("mobile_money")}</SelectItem>
              <SelectItem value="bank">{t("bank")}</SelectItem>
              <SelectItem value="other">{t("other")}</SelectItem>
            </SelectContent>
          </Select>
          <div className="rounded-lg bg-secondary p-3 text-sm">
            <div className="flex justify-between"><span>{t("total")}</span><span className="num font-bold">{money(total, currency)}</span></div>
            <div className="flex justify-between"><span>{t("balance")}</span><span className="num font-bold">{money(balance, currency)}</span></div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="secondary" onClick={onClose}>{t("cancel")}</Button>
          <Button disabled={save.isPending || lines.length === 0} onClick={() => save.mutate()}>{t("save")}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
