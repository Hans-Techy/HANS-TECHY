import { useEffect, type ReactNode } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useAuth, type Area } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";
import { AppShell } from "@/components/AppShell";

export function Guard({ area, title, children }: { area: Area; title: string; children: ReactNode }) {
  const { user, loading, can } = useAuth();
  const { t } = useI18n();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) void navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  if (loading || !user) {
    return (
      <div className="grid min-h-screen place-items-center text-sm text-muted-foreground">
        {t("loading")}
      </div>
    );
  }

  if (!can(area)) {
    return (
      <AppShell title={title}>
        <div className="stat-card text-center text-sm text-muted-foreground">{t("permissionDenied")}</div>
      </AppShell>
    );
  }

  return <AppShell title={title}>{children}</AppShell>;
}
