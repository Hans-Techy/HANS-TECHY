import { cn } from "@/lib/utils";

// Initials from the business name: "Hans Techy" -> "HT", "Duka" -> "DU".
export function brandInitials(name?: string | null) {
  const words = (name ?? "").trim().split(/\s+/).filter(Boolean);
  if (words.length === 0) return "HT";
  if (words.length === 1) return words[0].slice(0, 2).toUpperCase();
  return (words[0][0] + words[1][0]).toUpperCase();
}

export function BrandMark({
  name,
  logoUrl,
  size = 40,
  className,
}: {
  name?: string | null;
  logoUrl?: string | null;
  size?: number;
  className?: string;
}) {
  const initials = brandInitials(name);
  const radius = Math.round(size * 0.28);
  if (logoUrl) {
    return (
      <img
        src={logoUrl}
        alt={name ?? ""}
        className={cn("shrink-0 object-cover", className)}
        style={{ width: size, height: size, borderRadius: radius }}
      />
    );
  }
  return (
    <div
      key={initials}
      role="img"
      aria-label={name || "Hans Techy"}
      className={cn("anim-pop grid shrink-0 select-none place-items-center font-extrabold leading-none tracking-tight text-primary-foreground shadow-sm", className)}
      style={{
        width: size,
        height: size,
        borderRadius: radius,
        fontSize: size * 0.4,
        background: "linear-gradient(135deg, var(--primary), color-mix(in oklch, var(--primary) 68%, black))",
      }}
    >
      {initials}
    </div>
  );
}
