import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { BrandMark } from "@/components/BrandMark";
import { fetchSettings, qk } from "@/lib/data";
import { useState, type ReactNode } from "react";
import {
  LayoutDashboard,
  ShoppingCart,
  PackagePlus,
  Store,
  Users,
  Wallet,
  Receipt,
  BarChart3,
  UserCog,
  Settings as SettingsIcon,
  LogOut,
  Menu,
  Languages,
  MessageSquare,
} from "lucide-react";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { HansTechyAssistant } from "@/components/HansTechyAssistant";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, type Area } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";
import { InstallAppButton } from "@/components/InstallAppButton";
import { NotificationBell } from "@/components/NotificationBell";

const NAV: { to: string; area: Area; key: string; icon: typeof LayoutDashboard }[] = [
  { to: "/", area: "dashboard", key: "dashboard", icon: LayoutDashboard },
  { to: "/sales", area: "sales", key: "sales", icon: ShoppingCart },
  { to: "/purchases", area: "purchases", key: "purchases", icon: PackagePlus },
  { to: "/stock", area: "stock", key: "stock", icon: Store },
  { to: "/customers", area: "customers", key: "customers", icon: Users },
  { to: "/income", area: "income", key: "income", icon: Wallet },
  { to: "/expenses", area: "expenses", key: "expenses", icon: Receipt },
  { to: "/reports", area: "reports", key: "reports", icon: BarChart3 },
  { to: "/users", area: "users", key: "users", icon: UserCog },
  { to: "/settings", area: "settings", key: "settings", icon: SettingsIcon },
];

export function AppShell({ title, children }: { title: string; children: ReactNode }) {
  const { t, lang, setLang } = useI18n();
  const { data: biz } = useQuery({ queryKey: qk.settings, queryFn: fetchSettings });
  const { can, fullName, user } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  const signOut = async () => {
    await supabase.auth.signOut();
    void navigate({ to: "/auth" });
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 border-b border-border bg-background/95 backdrop-blur no-print">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-3 px-4">
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="secondary" size="icon" aria-label="Menu" className="size-11">
                <Menu className="size-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[280px] p-0">
              <SheetTitle className="sr-only">{t("appName")}</SheetTitle>
              <div className="flex items-center gap-3 border-b border-border px-4 py-4">
                <BrandMark name={biz?.name} logoUrl={biz?.logo_url} size={40} />
                <div className="leading-tight">
                  <p className="font-bold">{biz?.name || t("appName")}</p>
                  <p className="text-xs text-muted-foreground">{fullName || user?.email}</p>
                </div>
              </div>
              <nav className="flex flex-col gap-0.5 p-2">
                {NAV.filter((n) => can(n.area)).map((n) => {
                  const active = n.to === "/" ? pathname === "/" : pathname.startsWith(n.to);
                  return (
                    <Link
                      key={n.to}
                      to={n.to}
                      onClick={() => setOpen(false)}
                      className={`flex items-center gap-3 rounded-lg px-3 py-3 text-sm font-medium transition-colors ${
                        active
                          ? "bg-primary text-primary-foreground"
                          : "text-foreground hover:bg-secondary"
                      }`}
                    >
                      <n.icon className="size-5" />
                      {t(n.key)}
                    </Link>
                  );
                })}
                <Link
                  to="/feedback"
                  onClick={() => setOpen(false)}
                  className={`flex items-center gap-3 rounded-lg px-3 py-3 text-sm font-medium transition-colors ${
                    pathname.startsWith("/feedback") ? "bg-primary text-primary-foreground" : "text-foreground hover:bg-secondary"
                  }`}
                >
                  <MessageSquare className="size-5" />
                  {lang === "sw" ? "Mrejesho" : "Feedback"}
                </Link>
              </nav>
              <div className="mt-auto border-t border-border p-2">
                <InstallAppButton />
                <button
                  onClick={() => setLang(lang === "sw" ? "en" : "sw")}
                  className="flex w-full items-center gap-3 rounded-lg px-3 py-3 text-sm font-medium hover:bg-secondary"
                >
                  <Languages className="size-5" />
                  {t("language")}: {lang === "sw" ? "Kiswahili" : "English"}
                </button>
                <button
                  onClick={signOut}
                  className="flex w-full items-center gap-3 rounded-lg px-3 py-3 text-sm font-medium text-destructive hover:bg-secondary"
                >
                  <LogOut className="size-5" />
                  {t("logout")}
                </button>
              </div>
            </SheetContent>
          </Sheet>

          <h1 className="truncate text-lg font-bold tracking-tight">{title}</h1>

          <div className="ml-auto flex items-center gap-2">
            <NotificationBell />
            <Button
              variant="secondary"
              size="sm"
              className="h-10 font-semibold"
              onClick={() => setLang(lang === "sw" ? "en" : "sw")}
            >
              {lang === "sw" ? "SW" : "EN"}
            </Button>
            <div className="grid size-10 place-items-center rounded-lg bg-accent text-sm font-bold text-accent-foreground">
              {(fullName || user?.email || "?").charAt(0).toUpperCase()}
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-5 pb-16">{children}</main>
      <HansTechyAssistant />
    </div>
  );
}
