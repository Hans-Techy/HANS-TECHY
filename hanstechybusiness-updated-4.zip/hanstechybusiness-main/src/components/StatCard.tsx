import type { ReactNode } from "react";

export function StatCard({
  label,
  value,
  hint,
  tone = "default",
  icon,
}: {
  label: string;
  value: string;
  hint?: string;
  tone?: "default" | "profit" | "debt" | "warn";
  icon?: ReactNode;
}) {
  const toneClass =
    tone === "profit"
      ? "text-profit"
      : tone === "debt"
        ? "text-debt"
        : tone === "warn"
          ? "text-warn"
          : "text-foreground";

  return (
    <div className="stat-card">
      <div className="flex items-start justify-between gap-2">
        <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{label}</p>
        {icon}
      </div>
      <p className={`num mt-2 text-2xl font-bold leading-none ${toneClass}`}>{value}</p>
      {hint ? <p className="mt-1.5 text-xs text-muted-foreground">{hint}</p> : null}
    </div>
  );
}
